import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users and Authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("dentist"), // dentist, assistant, admin
  profilePicture: text("profile_picture"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastLogin: timestamp("last_login"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

// Patients
export const patients = pgTable("patients", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  dateOfBirth: timestamp("date_of_birth").notNull(),
  email: text("email"),
  phone: text("phone").notNull(),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  insurance: text("insurance"),
  insuranceId: text("insurance_id"),
  medicalHistory: text("medical_history"),
  allergies: text("allergies"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertPatientSchema = createInsertSchema(patients).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).transform((data) => ({
  ...data,
  // Ensure all optional fields have proper null values instead of undefined
  address: data.address || null,
  city: data.city || null,
  state: data.state || null,
  zipCode: data.zipCode || null,
  insurance: data.insurance || null,
  insuranceId: data.insuranceId || null,
  medicalHistory: data.medicalHistory || null,
  allergies: data.allergies || null,
  email: data.email || null
}));

// Appointments
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  doctorId: integer("doctor_id").notNull(),
  date: timestamp("date").notNull(),
  duration: integer("duration").notNull(), // in minutes
  type: text("type").notNull(), // check-up, cleaning, procedure, etc.
  notes: text("notes"),
  status: text("status").notNull().default("scheduled"), // scheduled, completed, cancelled, no-show
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Dental Charts
export const dentalCharts = pgTable("dental_charts", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  lastUpdatedBy: integer("last_updated_by").notNull(),
  data: jsonb("data").notNull(), // JSON data containing the state of all teeth
});

export const insertDentalChartSchema = createInsertSchema(dentalCharts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Clinical Notes
export const clinicalNotes = pgTable("clinical_notes", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  authorId: integer("author_id").notNull(),
  appointmentId: integer("appointment_id"),
  title: text("title").notNull(),
  content: text("content").notNull(),
  isAiGenerated: boolean("is_ai_generated").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertClinicalNoteSchema = createInsertSchema(clinicalNotes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Treatments
export const treatments = pgTable("treatments", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  doctorId: integer("doctor_id").notNull(),
  appointmentId: integer("appointment_id"),
  type: text("type").notNull(),
  description: text("description").notNull(),
  toothNumber: integer("tooth_number"), 
  status: text("status").notNull().default("planned"), // planned, in-progress, completed
  cost: text("cost"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  adaCode: text("ada_code"), // Official ADA code for the procedure
  surfaces: text("surfaces"), // Affected tooth surfaces (JSON string)
});

export const insertTreatmentSchema = createInsertSchema(treatments).omit({
  id: true,
  createdAt: true,
  completedAt: true,
}).transform((data) => ({
  ...data,
  appointmentId: data.appointmentId || null,
  toothNumber: data.toothNumber || null,
  cost: data.cost || null,
  adaCode: data.adaCode || null,
  surfaces: data.surfaces || null
}));

// ADA Procedure Codes
export const adaProcedureCodes = pgTable("ada_procedure_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // ADA procedure code (e.g., D0120)
  description: text("description").notNull(),
  category: text("category").notNull(), // Diagnostic, Preventive, Restorative, etc.
  fee: text("fee"), // Suggested fee
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAdaProcedureCodeSchema = createInsertSchema(adaProcedureCodes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// AI Suggestions
export const aiSuggestions = pgTable("ai_suggestions", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  suggestedBy: text("suggested_by").notNull(), // AI model that made suggestion
  content: text("content").notNull(),
  basedOn: text("based_on").notNull(), // dental chart, clinical history, x-ray, etc.
  status: text("status").notNull().default("pending"), // pending, approved, dismissed
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
  reviewedBy: integer("reviewed_by"),
});

export const insertAiSuggestionSchema = createInsertSchema(aiSuggestions).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
});

// Audit Logs
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  action: text("action").notNull(), // view, create, update, delete
  resourceType: text("resource_type").notNull(), // patient, appointment, chart, note, etc.
  resourceId: text("resource_id").notNull(),
  details: text("details"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  timestamp: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Patient = typeof patients.$inferSelect;
export type InsertPatient = z.infer<typeof insertPatientSchema>;

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;

export type DentalChart = typeof dentalCharts.$inferSelect;
export type InsertDentalChart = z.infer<typeof insertDentalChartSchema>;

export type ClinicalNote = typeof clinicalNotes.$inferSelect;
export type InsertClinicalNote = z.infer<typeof insertClinicalNoteSchema>;

export type Treatment = typeof treatments.$inferSelect;
export type InsertTreatment = z.infer<typeof insertTreatmentSchema>;

export type AdaProcedureCode = typeof adaProcedureCodes.$inferSelect;
export type InsertAdaProcedureCode = z.infer<typeof insertAdaProcedureCodeSchema>;

export type AiSuggestion = typeof aiSuggestions.$inferSelect;
export type InsertAiSuggestion = z.infer<typeof insertAiSuggestionSchema>;

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;

// Additional validation schemas
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export type LoginData = z.infer<typeof loginSchema>;
