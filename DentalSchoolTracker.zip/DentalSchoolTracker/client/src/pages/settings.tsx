import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

const profileFormSchema = z.object({
  firstName: z.string().min(2, { message: "First name must be at least 2 characters." }),
  lastName: z.string().min(2, { message: "Last name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  role: z.string({ required_error: "Please select a role." }),
  profilePicture: z.string().optional(),
});

const accountFormSchema = z.object({
  username: z.string().min(3, { message: "Username must be at least 3 characters." }),
  password: z
    .string()
    .min(6, { message: "Password must be at least 6 characters." })
    .optional(),
  confirmPassword: z.string().optional(),
}).refine(data => !data.password || data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

const securityFormSchema = z.object({
  sessionTimeout: z.number().min(5).max(60),
  autoLockScreen: z.boolean(),
  twoFactorAuth: z.boolean(),
  requirePasswordReset: z.number(),
  logFailedAttempts: z.boolean(),
});

const notificationFormSchema = z.object({
  emailAlerts: z.boolean(),
  reminderEmails: z.boolean(),
  securityAlerts: z.boolean(),
  marketingEmails: z.boolean(),
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;
type AccountFormValues = z.infer<typeof accountFormSchema>;
type SecurityFormValues = z.infer<typeof securityFormSchema>;
type NotificationFormValues = z.infer<typeof notificationFormSchema>;

const SettingsPage = () => {
  const { toast } = useToast();
  const { user, updateUser } = useAuth();
  
  const [isUpdating, setIsUpdating] = useState(false);
  
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      role: user?.role || "dentist",
      profilePicture: user?.profilePicture || "",
    },
  });
  
  const accountForm = useForm<AccountFormValues>({
    resolver: zodResolver(accountFormSchema),
    defaultValues: {
      username: user?.username || "",
      password: "",
      confirmPassword: "",
    },
  });
  
  const securityForm = useForm<SecurityFormValues>({
    resolver: zodResolver(securityFormSchema),
    defaultValues: {
      sessionTimeout: 15,
      autoLockScreen: true,
      twoFactorAuth: false,
      requirePasswordReset: 90,
      logFailedAttempts: true,
    },
  });
  
  const notificationForm = useForm<NotificationFormValues>({
    resolver: zodResolver(notificationFormSchema),
    defaultValues: {
      emailAlerts: true,
      reminderEmails: true,
      securityAlerts: true,
      marketingEmails: false,
    },
  });
  
  const onProfileSubmit = async (data: ProfileFormValues) => {
    if (!user) return;
    
    setIsUpdating(true);
    
    try {
      await apiRequest("PATCH", `/api/users/${user.id}`, data);
      
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated.",
      });
      
      // Update user context
      updateUser({
        ...user,
        ...data,
      });
      
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update profile information.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };
  
  const onAccountSubmit = async (data: AccountFormValues) => {
    if (!user) return;
    
    setIsUpdating(true);
    
    try {
      const payload = {
        username: data.username,
      };
      
      // Only include password if it was provided
      if (data.password) {
        Object.assign(payload, { password: data.password });
      }
      
      await apiRequest("PATCH", `/api/users/${user.id}`, payload);
      
      toast({
        title: "Account updated",
        description: "Your account information has been updated.",
      });
      
      // Update username in user context
      updateUser({
        ...user,
        username: data.username,
      });
      
      // Clear password fields
      accountForm.setValue("password", "");
      accountForm.setValue("confirmPassword", "");
      
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update account information.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };
  
  const onSecuritySubmit = async (data: SecurityFormValues) => {
    setIsUpdating(true);
    
    try {
      await apiRequest("POST", "/api/settings/security", data);
      
      toast({
        title: "Security settings updated",
        description: "Your security settings have been updated.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update security settings.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };
  
  const onNotificationSubmit = async (data: NotificationFormValues) => {
    setIsUpdating(true);
    
    try {
      await apiRequest("POST", "/api/settings/notifications", data);
      
      toast({
        title: "Notification settings updated",
        description: "Your notification preferences have been updated.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update notification settings.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Settings</h2>
        <p className="text-sm text-gray-500 mt-1">
          Manage your account settings and preferences
        </p>
      </div>
      
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="w-full border-b rounded-none justify-start mb-4">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="hipaa">HIPAA Compliance</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                Update your personal information and profile settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...profileForm}>
                <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={profileForm.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={profileForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input {...field} type="email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={profileForm.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Role</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select role" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="dentist">Dentist</SelectItem>
                            <SelectItem value="assistant">Dental Assistant</SelectItem>
                            <SelectItem value="admin">Administrator</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={profileForm.control}
                    name="profilePicture"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Profile Picture URL</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="https://example.com/avatar.jpg" />
                        </FormControl>
                        <FormDescription>
                          Enter a URL for your profile picture (optional)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <CardFooter className="flex justify-end px-0 pt-4">
                    <Button type="submit" disabled={isUpdating}>
                      {isUpdating ? (
                        <>
                          <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                          Updating...
                        </>
                      ) : "Save Changes"}
                    </Button>
                  </CardFooter>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>
                Update your username and password
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...accountForm}>
                <form onSubmit={accountForm.handleSubmit(onAccountSubmit)} className="space-y-4">
                  <FormField
                    control={accountForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={accountForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>New Password</FormLabel>
                        <FormControl>
                          <Input {...field} type="password" placeholder="Leave blank to keep current password" />
                        </FormControl>
                        <FormDescription>
                          Passwords must be at least 6 characters
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={accountForm.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirm New Password</FormLabel>
                        <FormControl>
                          <Input {...field} type="password" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <CardFooter className="flex justify-end px-0 pt-4">
                    <Button type="submit" disabled={isUpdating}>
                      {isUpdating ? (
                        <>
                          <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                          Updating...
                        </>
                      ) : "Update Account"}
                    </Button>
                  </CardFooter>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Manage security options and access controls
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...securityForm}>
                <form onSubmit={securityForm.handleSubmit(onSecuritySubmit)} className="space-y-4">
                  <FormField
                    control={securityForm.control}
                    name="sessionTimeout"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between items-center">
                          <FormLabel>Session Timeout (minutes)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              className="w-20 text-right"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                        </div>
                        <FormDescription>
                          Automatically log out after a period of inactivity (HIPAA compliant)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={securityForm.control}
                    name="autoLockScreen"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Auto-Lock Screen</FormLabel>
                          <FormDescription>
                            Lock screen automatically when inactive (HIPAA compliant)
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={securityForm.control}
                    name="twoFactorAuth"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Two-Factor Authentication</FormLabel>
                          <FormDescription>
                            Require a second authentication method when logging in
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={securityForm.control}
                    name="requirePasswordReset"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between items-center">
                          <FormLabel>Password Reset (days)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              className="w-20 text-right"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                        </div>
                        <FormDescription>
                          Require password change every set number of days
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={securityForm.control}
                    name="logFailedAttempts"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Log Failed Login Attempts</FormLabel>
                          <FormDescription>
                            Track and log all failed authentication attempts
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <CardFooter className="flex justify-end px-0 pt-4">
                    <Button type="submit" disabled={isUpdating}>
                      {isUpdating ? (
                        <>
                          <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                          Updating...
                        </>
                      ) : "Save Security Settings"}
                    </Button>
                  </CardFooter>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>
                Manage how you receive notifications and alerts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...notificationForm}>
                <form onSubmit={notificationForm.handleSubmit(onNotificationSubmit)} className="space-y-4">
                  <FormField
                    control={notificationForm.control}
                    name="emailAlerts"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Email Alerts</FormLabel>
                          <FormDescription>
                            Receive important alerts via email
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={notificationForm.control}
                    name="reminderEmails"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Appointment Reminders</FormLabel>
                          <FormDescription>
                            Receive reminders about upcoming appointments
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={notificationForm.control}
                    name="securityAlerts"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Security Alerts</FormLabel>
                          <FormDescription>
                            Get notified about security-related events
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={notificationForm.control}
                    name="marketingEmails"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Marketing & Newsletter</FormLabel>
                          <FormDescription>
                            Receive marketing materials and newsletters
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <CardFooter className="flex justify-end px-0 pt-4">
                    <Button type="submit" disabled={isUpdating}>
                      {isUpdating ? (
                        <>
                          <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                          Updating...
                        </>
                      ) : "Save Notification Preferences"}
                    </Button>
                  </CardFooter>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="hipaa">
          <Card>
            <CardHeader>
              <CardTitle>HIPAA Compliance Settings</CardTitle>
              <CardDescription>
                Manage settings related to HIPAA compliance and data security
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-md p-4 text-sm text-blue-800">
                <div className="flex items-start">
                  <i className="ri-information-line mr-2 mt-0.5"></i>
                  <div>
                    <p className="font-medium">HIPAA Compliance Information</p>
                    <p className="mt-1">
                      This system is designed to comply with HIPAA regulations for the protection of patient health information.
                      The settings below help ensure that your practice remains compliant with these regulations.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="rounded-lg border p-4">
                <h3 className="text-base font-medium mb-2">Access Controls</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Switch id="audit-logging" defaultChecked disabled />
                    <label htmlFor="audit-logging" className="ml-2 text-sm font-medium">
                      Enable audit logging (Required)
                    </label>
                  </div>
                  <p className="text-xs text-gray-500">
                    System automatically logs all access to protected health information
                  </p>
                </div>
              </div>
              
              <div className="rounded-lg border p-4">
                <h3 className="text-base font-medium mb-2">Data Protection</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Switch id="data-encryption" defaultChecked disabled />
                    <label htmlFor="data-encryption" className="ml-2 text-sm font-medium">
                      Encrypt sensitive data (Required)
                    </label>
                  </div>
                  <p className="text-xs text-gray-500">
                    All PHI is encrypted both in transit and at rest
                  </p>
                </div>
              </div>
              
              <div className="rounded-lg border p-4">
                <h3 className="text-base font-medium mb-2">Authorization</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Switch id="role-based-access" defaultChecked />
                    <label htmlFor="role-based-access" className="ml-2 text-sm font-medium">
                      Use role-based access controls
                    </label>
                  </div>
                  <p className="text-xs text-gray-500">
                    Restrict access to PHI based on user roles
                  </p>
                </div>
              </div>
              
              <div className="rounded-lg border p-4">
                <h3 className="text-base font-medium mb-2">Privacy Policy</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Switch id="show-privacy-notice" defaultChecked />
                    <label htmlFor="show-privacy-notice" className="ml-2 text-sm font-medium">
                      Display privacy policy notice
                    </label>
                  </div>
                  <p className="text-xs text-gray-500">
                    Show privacy policy information in the footer of the application
                  </p>
                </div>
              </div>
              
              <CardFooter className="flex justify-end px-0 pt-4">
                <Button>
                  Save HIPAA Settings
                </Button>
              </CardFooter>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SettingsPage;
