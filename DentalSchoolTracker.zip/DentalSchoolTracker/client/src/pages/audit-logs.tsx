import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { AuditLog } from "@shared/schema";
import { useAuth } from "@/lib/auth";

const AuditLogs = () => {
  const [actionType, setActionType] = useState<string>("all");
  const [resourceType, setResourceType] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [dateRange, setDateRange] = useState("all");
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [showLogDetails, setShowLogDetails] = useState(false);
  
  const { user } = useAuth();
  
  // Check if user is admin
  const isAdmin = user?.role === "admin";
  
  // Get audit logs
  const { data: auditLogs, isLoading } = useQuery({
    queryKey: ["/api/audit-logs", { action: actionType, resource: resourceType, dateRange }],
    enabled: isAdmin, // Only fetch if user is admin
  });
  
  // Get users for displaying names
  const { data: users } = useQuery({
    queryKey: ["/api/users"],
    enabled: isAdmin,
  });
  
  const handleViewLogDetails = (log: AuditLog) => {
    setSelectedLog(log);
    setShowLogDetails(true);
  };
  
  // Filter logs by search query
  const filteredLogs = auditLogs 
    ? auditLogs.filter((log: AuditLog) => {
        if (!searchQuery) return true;
        
        const searchLower = searchQuery.toLowerCase();
        const userMatch = users && users.find((u: any) => u.id === log.userId);
        const userName = userMatch ? `${userMatch.firstName} ${userMatch.lastName}`.toLowerCase() : "";
        
        return log.action.toLowerCase().includes(searchLower)
          || log.resourceType.toLowerCase().includes(searchLower)
          || log.resourceId.toLowerCase().includes(searchLower)
          || log.details.toLowerCase().includes(searchLower)
          || userName.includes(searchLower);
      })
    : [];
  
  // Get badge color based on action type
  const getActionBadgeColor = (action: string) => {
    switch (action) {
      case "view":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "create":
        return "bg-green-100 text-green-800 border-green-200";
      case "update":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "delete":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };
  
  // Get resource badge color
  const getResourceBadgeColor = (resourceType: string) => {
    switch (resourceType) {
      case "patient":
        return "bg-purple-100 text-purple-800 border-purple-200";
      case "appointment":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "dental-chart":
        return "bg-teal-100 text-teal-800 border-teal-200";
      case "clinical-note":
        return "bg-green-100 text-green-800 border-green-200";
      case "user":
        return "bg-orange-100 text-orange-800 border-orange-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };
  
  if (!isAdmin) {
    return (
      <div className="text-center py-10">
        <div className="text-gray-400 mb-3">
          <i className="ri-shield-check-line text-5xl"></i>
        </div>
        <h3 className="text-xl font-medium text-gray-900">Access Restricted</h3>
        <p className="mt-2 text-gray-500 max-w-md mx-auto">
          You don't have permission to view audit logs. This feature is restricted to administrators only.
        </p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Audit Logs</h2>
          <p className="text-sm text-gray-500 mt-1">
            HIPAA compliant audit trail of system access and actions
          </p>
        </div>
        <div>
          <Button variant="outline">
            <i className="ri-download-line mr-1"></i>
            Export Logs
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Filter Options</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search
              </label>
              <Input
                placeholder="Search logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Action Type
              </label>
              <Select
                value={actionType}
                onValueChange={setActionType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All actions" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All actions</SelectItem>
                  <SelectItem value="view">View</SelectItem>
                  <SelectItem value="create">Create</SelectItem>
                  <SelectItem value="update">Update</SelectItem>
                  <SelectItem value="delete">Delete</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Resource Type
              </label>
              <Select
                value={resourceType}
                onValueChange={setResourceType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All resources" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All resources</SelectItem>
                  <SelectItem value="patient">Patient</SelectItem>
                  <SelectItem value="appointment">Appointment</SelectItem>
                  <SelectItem value="dental-chart">Dental Chart</SelectItem>
                  <SelectItem value="clinical-note">Clinical Note</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date Range
              </label>
              <Select
                value={dateRange}
                onValueChange={setDateRange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">Last 7 days</SelectItem>
                  <SelectItem value="month">Last 30 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Audit Log Records</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : filteredLogs.length > 0 ? (
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[180px]">Timestamp</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Resource</TableHead>
                    <TableHead className="hidden md:table-cell">Details</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log: AuditLog) => {
                    const userMatch = users && users.find((u: any) => u.id === log.userId);
                    const userName = userMatch 
                      ? `${userMatch.firstName} ${userMatch.lastName}` 
                      : `User ID: ${log.userId}`;
                      
                    return (
                      <TableRow key={log.id}>
                        <TableCell className="font-medium">
                          {format(new Date(log.timestamp), "MMM d, yyyy HH:mm:ss")}
                        </TableCell>
                        <TableCell>{userName}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={getActionBadgeColor(log.action)}>
                            {log.action}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Badge variant="outline" className={getResourceBadgeColor(log.resourceType)}>
                              {log.resourceType}
                            </Badge>
                            <span className="ml-2 text-xs text-gray-500">
                              ID: {log.resourceId}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <span className="truncate block max-w-xs">
                            {log.details}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleViewLogDetails(log)}
                          >
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="text-gray-400 mb-3">
                <i className="ri-file-search-line text-3xl"></i>
              </div>
              <h3 className="text-lg font-medium text-gray-900">No logs found</h3>
              <p className="mt-1 text-sm text-gray-500">
                No audit logs match your current filter criteria.
              </p>
              <Button 
                className="mt-4"
                variant="outline"
                onClick={() => {
                  setActionType("all");
                  setResourceType("all");
                  setDateRange("all");
                  setSearchQuery("");
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* View Log Details Dialog */}
      <Dialog open={showLogDetails} onOpenChange={setShowLogDetails}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Audit Log Details</DialogTitle>
            <DialogDescription>
              Detailed information about the selected audit log
            </DialogDescription>
          </DialogHeader>
          
          {selectedLog && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Timestamp</h3>
                  <p>{format(new Date(selectedLog.timestamp), "MMMM d, yyyy HH:mm:ss")}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">User</h3>
                  <p>
                    {users && users.find((u: any) => u.id === selectedLog.userId)
                      ? `${users.find((u: any) => u.id === selectedLog.userId).firstName} ${users.find((u: any) => u.id === selectedLog.userId).lastName}`
                      : `User ID: ${selectedLog.userId}`}
                  </p>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Action</h3>
                <Badge variant="outline" className={`${getActionBadgeColor(selectedLog.action)} mt-1`}>
                  {selectedLog.action}
                </Badge>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Resource</h3>
                <div className="flex items-center mt-1">
                  <Badge variant="outline" className={getResourceBadgeColor(selectedLog.resourceType)}>
                    {selectedLog.resourceType}
                  </Badge>
                  <span className="ml-2">
                    ID: {selectedLog.resourceId}
                  </span>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Details</h3>
                <p className="mt-1">{selectedLog.details}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">IP Address</h3>
                  <p>{selectedLog.ipAddress || "Not recorded"}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">User Agent</h3>
                  <p className="truncate">{selectedLog.userAgent || "Not recorded"}</p>
                </div>
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 text-sm text-yellow-800">
                <div className="flex items-start">
                  <i className="ri-information-line mr-2 mt-0.5"></i>
                  <div>
                    <p className="font-medium">HIPAA Compliance Information</p>
                    <p className="mt-1">
                      This audit log is stored in accordance with HIPAA regulations, which require
                      maintaining detailed access logs for protected health information.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AuditLogs;
