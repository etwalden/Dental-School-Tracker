import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { insertPatientSchema, Patient, Appointment, ClinicalNote, DentalChart, Treatment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "@/lib/auth";
import { format, parseISO } from "date-fns";
import DentalChartComponent from "@/components/ui/dental-chart";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

interface PatientDetailProps {
  id: string;
}

const PatientDetail = ({ id }: PatientDetailProps) => {
  const patientId = parseInt(id);
  const { toast } = useToast();
  const { user } = useAuth();
  const [editMode, setEditMode] = useState(false);
  
  // Get patient details
  const { data: patient, isLoading: isLoadingPatient } = useQuery({
    queryKey: [`/api/patients/${patientId}`],
  });
  
  // Get patient appointments
  const { data: appointments } = useQuery({
    queryKey: [`/api/appointments/patient/${patientId}`],
  });
  
  // Get patient clinical notes
  const { data: clinicalNotes } = useQuery({
    queryKey: [`/api/clinical-notes/patient/${patientId}`],
  });
  
  // Get patient dental chart
  const { data: dentalChart } = useQuery({
    queryKey: [`/api/dental-charts/patient/${patientId}`],
  });
  
  // Get patient treatments
  const { data: treatments } = useQuery({
    queryKey: [`/api/treatments/patient/${patientId}`],
  });
  
  // Log audit when viewing patient record
  useEffect(() => {
    if (user?.id && patientId) {
      const logAudit = async () => {
        try {
          await apiRequest("POST", "/api/audit-logs", {
            userId: user.id,
            action: "view",
            resourceType: "patient",
            resourceId: patientId.toString(),
            details: `Viewed patient record: ${patientId}`,
            ipAddress: "0.0.0.0", // This would be captured on server side
            userAgent: navigator.userAgent
          });
        } catch (error) {
          console.error("Failed to log audit", error);
        }
      };
      
      logAudit();
    }
  }, [user, patientId]);
  
  const form = useForm({
    resolver: zodResolver(insertPatientSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      dateOfBirth: new Date(),
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      insurance: "",
      insuranceId: "",
      medicalHistory: "",
      allergies: "",
    },
  });
  
  // Set form values when patient data is loaded
  useEffect(() => {
    if (patient) {
      form.reset({
        ...patient,
        dateOfBirth: patient.dateOfBirth ? new Date(patient.dateOfBirth) : new Date(),
      });
    }
  }, [patient, form]);
  
  const handleUpdatePatient = async (data: any) => {
    try {
      await apiRequest("PATCH", `/api/patients/${patientId}`, data);
      
      toast({
        title: "Patient updated",
        description: "Patient information has been successfully updated.",
      });
      
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${patientId}`] });
      
      setEditMode(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem updating patient information.",
        variant: "destructive",
      });
    }
  };
  
  if (isLoadingPatient) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!patient) {
    return (
      <div className="text-center py-10">
        <div className="text-gray-400 mb-3">
          <i className="ri-error-warning-line text-4xl"></i>
        </div>
        <h3 className="text-lg font-medium text-gray-900">Patient not found</h3>
        <p className="mt-1 text-sm text-gray-500">
          The patient you are looking for does not exist or has been deleted.
        </p>
        <Link href="/patients">
          <Button className="mt-4">Back to Patients</Button>
        </Link>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold">
            {patient.firstName} {patient.lastName}
          </h2>
          <p className="text-gray-500">
            {patient.dateOfBirth && 
              `${format(new Date(patient.dateOfBirth), "MMMM d, yyyy")} · ${patient.email || "No email"} · ${patient.phone}`
            }
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center"
            onClick={() => setEditMode(!editMode)}
          >
            <i className="ri-pencil-line mr-1"></i>
            {editMode ? "Cancel Edit" : "Edit Patient"}
          </Button>
          <Button className="bg-primary text-white flex items-center">
            <i className="ri-calendar-line mr-1"></i>
            Schedule Appointment
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="overview">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="appointments">Appointments</TabsTrigger>
          <TabsTrigger value="dental-chart">Dental Chart</TabsTrigger>
          <TabsTrigger value="clinical-notes">Clinical Notes</TabsTrigger>
          <TabsTrigger value="treatments">Treatments</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          {editMode ? (
            <Card>
              <CardHeader>
                <CardTitle>Edit Patient Information</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleUpdatePatient)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="dateOfBirth"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date of Birth</FormLabel>
                            <FormControl>
                              <Input 
                                type="date" 
                                value={field.value instanceof Date ? format(field.value, "yyyy-MM-dd") : ""} 
                                onChange={(e) => field.onChange(new Date(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input {...field} className="hipaa-field" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input {...field} className="hipaa-field" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address</FormLabel>
                          <FormControl>
                            <Input {...field} className="hipaa-field" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>State</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="zipCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Zip Code</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="insurance"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Insurance Provider</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="insuranceId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Insurance ID</FormLabel>
                            <FormControl>
                              <Input {...field} className="hipaa-field" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="medicalHistory"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Medical History</FormLabel>
                            <FormControl>
                              <Textarea {...field} className="hipaa-field" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="allergies"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Allergies</FormLabel>
                            <FormControl>
                              <Textarea {...field} className="hipaa-field" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setEditMode(false)}
                      >
                        Cancel
                      </Button>
                      <Button type="submit" className="bg-primary">
                        Save Changes
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Full Name</h4>
                        <p>{patient.firstName} {patient.lastName}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Date of Birth</h4>
                        <p>{patient.dateOfBirth ? format(new Date(patient.dateOfBirth), "MMMM d, yyyy") : "N/A"}</p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Contact Information</h4>
                      <div className="grid grid-cols-2 gap-4 mt-2">
                        <div>
                          <p className="text-xs text-gray-500">Phone</p>
                          <p className="hipaa-field pl-2">{patient.phone}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Email</p>
                          <p className="hipaa-field pl-2">{patient.email || "No email"}</p>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Address</h4>
                      <p className="hipaa-field pl-2">{patient.address || "No address"}</p>
                      {(patient.city || patient.state || patient.zipCode) && (
                        <p>{patient.city}{patient.city && patient.state ? ", " : ""}{patient.state} {patient.zipCode}</p>
                      )}
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Insurance</h4>
                      <div className="grid grid-cols-2 gap-4 mt-2">
                        <div>
                          <p className="text-xs text-gray-500">Provider</p>
                          <p>{patient.insurance || "No insurance"}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">ID</p>
                          <p className="hipaa-field pl-2">{patient.insuranceId || "No ID"}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Medical Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Medical History</h4>
                      <p className="hipaa-field pl-2 mt-1">{patient.medicalHistory || "No medical history"}</p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Allergies</h4>
                      <p className="hipaa-field pl-2 mt-1">{patient.allergies || "No allergies"}</p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Last Visit</h4>
                      <p className="mt-1">
                        {appointments && appointments.length > 0 
                          ? format(new Date(appointments[0].date), "MMMM d, yyyy")
                          : "No previous visits"}
                      </p>
                    </div>
                    
                    <Separator />
                    
                    <div className="text-center pt-2">
                      <Button variant="outline" className="w-full">
                        <i className="ri-file-text-line mr-1"></i>
                        Download Medical History
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="appointments">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Appointment History</CardTitle>
              <Button className="bg-primary text-white">
                <i className="ri-calendar-line mr-1"></i>
                Schedule New Appointment
              </Button>
            </CardHeader>
            <CardContent>
              {appointments && appointments.length > 0 ? (
                <div className="space-y-4">
                  {appointments.map((appointment: Appointment) => (
                    <div key={appointment.id} className="border rounded-md p-4 hover:bg-gray-50">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center mb-1">
                            <h3 className="font-medium">{format(new Date(appointment.date), "MMMM d, yyyy")}</h3>
                            <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                              appointment.type === 'check-up' ? 'bg-blue-100 text-blue-700' :
                              appointment.type === 'cleaning' ? 'bg-green-100 text-green-700' :
                              appointment.type === 'root canal' ? 'bg-red-100 text-red-700' :
                              appointment.type === 'consultation' ? 'bg-purple-100 text-purple-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {appointment.type}
                            </span>
                            <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                              appointment.status === 'scheduled' ? 'bg-blue-100 text-blue-700' :
                              appointment.status === 'completed' ? 'bg-green-100 text-green-700' :
                              appointment.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                              appointment.status === 'no-show' ? 'bg-yellow-100 text-yellow-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {appointment.status}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500">
                            {format(new Date(appointment.date), "h:mm a")} · {appointment.duration} minutes
                          </p>
                          {appointment.notes && (
                            <p className="text-sm text-gray-600 mt-2">{appointment.notes}</p>
                          )}
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <i className="ri-file-text-line mr-1"></i>
                            View Notes
                          </Button>
                          <Button variant="outline" size="sm">
                            <i className="ri-calendar-line mr-1"></i>
                            Reschedule
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-3">
                    <i className="ri-calendar-line text-3xl"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900">No appointment history</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    This patient doesn't have any past or upcoming appointments.
                  </p>
                  <Button className="mt-4">
                    Schedule First Appointment
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="dental-chart">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Dental Chart</CardTitle>
              <Link href={`/dental-charts?patientId=${patientId}`}>
                <Button className="bg-primary text-white">
                  <i className="ri-edit-line mr-1"></i>
                  Edit Dental Chart
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {dentalChart ? (
                <DentalChartComponent 
                  data={dentalChart.data}
                  editable={false}
                />
              ) : (
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-3">
                    <i className="ri-teeth-line text-3xl"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900">No dental chart</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    This patient doesn't have a dental chart yet.
                  </p>
                  <Link href={`/dental-charts?patientId=${patientId}`}>
                    <Button className="mt-4">
                      Create Dental Chart
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="clinical-notes">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Clinical Notes</CardTitle>
              <Link href={`/clinical-notes?patientId=${patientId}`}>
                <Button className="bg-primary text-white">
                  <i className="ri-add-line mr-1"></i>
                  Add Clinical Note
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {clinicalNotes && clinicalNotes.length > 0 ? (
                <div className="space-y-4">
                  {clinicalNotes.map((note: ClinicalNote) => (
                    <div key={note.id} className="border rounded-md p-4 hover:bg-gray-50">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center mb-1">
                            <h3 className="font-medium">{note.title}</h3>
                            {note.isAiGenerated && (
                              <span className="ml-2 text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full flex items-center">
                                <i className="ri-robot-line mr-1"></i>
                                AI Generated
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-500">
                            {format(new Date(note.createdAt), "MMMM d, yyyy")} · Dr. {note.authorId}
                          </p>
                          <p className="hipaa-field pl-2 mt-2 text-sm">
                            {note.content.length > 150 
                              ? `${note.content.substring(0, 150)}...` 
                              : note.content}
                          </p>
                        </div>
                        <div className="flex space-x-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <i className="ri-file-text-line mr-1"></i>
                                View Full Note
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-[600px]">
                              <DialogHeader>
                                <DialogTitle>{note.title}</DialogTitle>
                              </DialogHeader>
                              <div className="py-4">
                                <p className="text-sm text-gray-500 mb-4">
                                  {format(new Date(note.createdAt), "MMMM d, yyyy")} · Dr. {note.authorId}
                                  {note.isAiGenerated && (
                                    <span className="ml-2 text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">
                                      AI Generated
                                    </span>
                                  )}
                                </p>
                                <div className="hipaa-field pl-2 py-2">
                                  <p className="whitespace-pre-wrap">{note.content}</p>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-3">
                    <i className="ri-file-text-line text-3xl"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900">No clinical notes</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    This patient doesn't have any clinical notes yet.
                  </p>
                  <Link href={`/clinical-notes?patientId=${patientId}`}>
                    <Button className="mt-4">
                      Create First Clinical Note
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="treatments">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Treatment History</CardTitle>
              <Button className="bg-primary text-white">
                <i className="ri-add-line mr-1"></i>
                Add Treatment
              </Button>
            </CardHeader>
            <CardContent>
              {treatments && treatments.length > 0 ? (
                <div className="space-y-4">
                  {treatments.map((treatment: Treatment) => (
                    <div key={treatment.id} className="border rounded-md p-4 hover:bg-gray-50">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center mb-1">
                            <h3 className="font-medium">{treatment.type}</h3>
                            <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                              treatment.status === 'planned' ? 'bg-blue-100 text-blue-700' :
                              treatment.status === 'in-progress' ? 'bg-yellow-100 text-yellow-700' :
                              treatment.status === 'completed' ? 'bg-green-100 text-green-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {treatment.status}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500">
                            {treatment.createdAt && format(new Date(treatment.createdAt), "MMMM d, yyyy")}
                            {treatment.toothNumber && ` · Tooth #${treatment.toothNumber}`}
                            {treatment.cost && ` · Cost: ${treatment.cost}`}
                          </p>
                          <p className="mt-2 text-sm">{treatment.description}</p>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <i className="ri-edit-line mr-1"></i>
                            Update Status
                          </Button>
                          <Button variant="outline" size="sm">
                            <i className="ri-file-text-line mr-1"></i>
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-3">
                    <i className="ri-heart-pulse-line text-3xl"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900">No treatments</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    This patient doesn't have any treatment records yet.
                  </p>
                  <Button className="mt-4">
                    Add First Treatment
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PatientDetail;
