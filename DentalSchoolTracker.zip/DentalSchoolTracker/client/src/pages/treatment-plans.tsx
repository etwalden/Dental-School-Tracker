import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { insertTreatmentSchema, Treatment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";

// ADA procedure code categories
const ADA_CATEGORIES = [
  { id: "diagnostic", name: "Diagnostic", color: "bg-blue-100 text-blue-800" },
  { id: "preventive", name: "Preventive", color: "bg-green-100 text-green-800" },
  { id: "restorative", name: "Restorative", color: "bg-orange-100 text-orange-800" },
  { id: "endodontics", name: "Endodontics", color: "bg-red-100 text-red-800" },
  { id: "periodontics", name: "Periodontics", color: "bg-purple-100 text-purple-800" },
  { id: "prosthodontics", name: "Prosthodontics", color: "bg-indigo-100 text-indigo-800" },
  { id: "oral-surgery", name: "Oral Surgery", color: "bg-yellow-100 text-yellow-800" },
  { id: "orthodontics", name: "Orthodontics", color: "bg-pink-100 text-pink-800" },
];

// Sample ADA codes - will be replaced with API data
const SAMPLE_ADA_CODES = [
  { code: "D0120", description: "Periodic oral evaluation", category: "diagnostic", fee: "58.00" },
  { code: "D0150", description: "Comprehensive oral evaluation", category: "diagnostic", fee: "93.00" },
  { code: "D0210", description: "Intraoral - complete series of radiographic images", category: "diagnostic", fee: "125.00" },
  { code: "D1110", description: "Prophylaxis - adult", category: "preventive", fee: "94.00" },
  { code: "D1120", description: "Prophylaxis - child", category: "preventive", fee: "68.00" },
  { code: "D1351", description: "Sealant - per tooth", category: "preventive", fee: "49.00" },
  { code: "D2140", description: "Amalgam - one surface, primary or permanent", category: "restorative", fee: "132.00" },
  { code: "D2150", description: "Amalgam - two surfaces, primary or permanent", category: "restorative", fee: "168.00" },
  { code: "D2160", description: "Amalgam - three surfaces, primary or permanent", category: "restorative", fee: "204.00" },
  { code: "D2330", description: "Resin-based composite - one surface, anterior", category: "restorative", fee: "149.00" },
  { code: "D2331", description: "Resin-based composite - two surfaces, anterior", category: "restorative", fee: "189.00" },
  { code: "D2391", description: "Resin-based composite - one surface, posterior", category: "restorative", fee: "159.00" },
  { code: "D2392", description: "Resin-based composite - two surfaces, posterior", category: "restorative", fee: "209.00" },
  { code: "D2740", description: "Crown - porcelain/ceramic", category: "restorative", fee: "1072.00" },
  { code: "D2750", description: "Crown - porcelain fused to high noble metal", category: "restorative", fee: "1020.00" },
  { code: "D3310", description: "Endodontic therapy - anterior tooth", category: "endodontics", fee: "787.00" },
  { code: "D3320", description: "Endodontic therapy - premolar tooth", category: "endodontics", fee: "904.00" },
  { code: "D3330", description: "Endodontic therapy - molar tooth", category: "endodontics", fee: "1096.00" },
  { code: "D4341", description: "Periodontal scaling and root planing - four or more teeth per quadrant", category: "periodontics", fee: "225.00" },
  { code: "D7140", description: "Extraction, erupted tooth or exposed root", category: "oral-surgery", fee: "168.00" },
];

const TreatmentPlans = () => {
  const [location] = useLocation();
  const [selectedPatientId, setSelectedPatientId] = useState<number | null>(null);
  const [showNewTreatmentDialog, setShowNewTreatmentDialog] = useState(false);
  const [selectedTreatment, setSelectedTreatment] = useState<Treatment | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedADACode, setSelectedADACode] = useState<string | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Extract patientId from URL if present
  useState(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const patientId = params.get('patientId');
    if (patientId) {
      setSelectedPatientId(parseInt(patientId));
    }
  });
  
  // Get patients
  const { data: patients } = useQuery({
    queryKey: ["/api/patients"],
  });
  
  // Get treatments for selected patient
  const { data: treatments, isLoading: isLoadingTreatments } = useQuery({
    queryKey: ["/api/treatments/patient", selectedPatientId],
    enabled: !!selectedPatientId,
  });
  
  // Get ADA procedure codes
  const { data: adaCodes = SAMPLE_ADA_CODES } = useQuery({
    queryKey: ["/api/ada-procedure-codes"],
  });
  
  // Filter ADA codes by category
  const filteredAdaCodes = selectedCategory 
    ? adaCodes.filter((code: any) => code.category === selectedCategory)
    : adaCodes;
  
  // Form for new treatment
  const form = useForm({
    resolver: zodResolver(insertTreatmentSchema),
    defaultValues: {
      patientId: selectedPatientId || 0,
      doctorId: user?.id || 0,
      type: "",
      description: "",
      status: "planned",
      toothNumber: null,
      cost: null,
      appointmentId: null,
      adaCode: null,
      surfaces: null,
    },
  });
  
  // Update form when patient is selected
  useState(() => {
    if (selectedPatientId) {
      form.setValue("patientId", selectedPatientId);
    }
    
    if (user) {
      form.setValue("doctorId", user.id);
    }
  });
  
  // Update form when ADA code is selected
  useState(() => {
    if (selectedADACode) {
      const adaCodeData = adaCodes.find((code: any) => code.code === selectedADACode);
      if (adaCodeData) {
        form.setValue("type", adaCodeData.description);
        form.setValue("adaCode", adaCodeData.code);
        form.setValue("cost", adaCodeData.fee);
      }
    }
  });
  
  const handlePatientChange = (patientId: string) => {
    setSelectedPatientId(parseInt(patientId));
  };
  
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category || null);
    setSelectedADACode(null);
  };
  
  const handleADACodeChange = (code: string) => {
    setSelectedADACode(code || null);
    
    if (code) {
      const adaCodeData = adaCodes.find((c: any) => c.code === code);
      if (adaCodeData) {
        form.setValue("type", adaCodeData.description);
        form.setValue("adaCode", adaCodeData.code);
        form.setValue("cost", adaCodeData.fee);
      }
    }
  };
  
  const onSubmit = async (data: any) => {
    try {
      // Format the data for API
      const formattedData = {
        ...data,
        surfaces: data.surfaces ? JSON.stringify(data.surfaces) : null
      };
      
      const response = await apiRequest("POST", "/api/treatments", formattedData);
      const newTreatment = await response.json();
      
      toast({
        title: "Success",
        description: "Treatment plan has been saved",
      });
      
      // Reset form and close dialog
      form.reset();
      setShowNewTreatmentDialog(false);
      
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/treatments"] });
      
      if (selectedPatientId) {
        queryClient.invalidateQueries({ queryKey: ["/api/treatments/patient", selectedPatientId] });
      }
    } catch (error) {
      console.error("Error saving treatment plan:", error);
      toast({
        title: "Error",
        description: "Failed to save treatment plan",
        variant: "destructive",
      });
    }
  };
  
  const renderTreatmentsList = (treatmentsList: Treatment[]) => {
    if (!treatmentsList || treatmentsList.length === 0) {
      return (
        <div className="text-center py-8">
          <div className="text-gray-400 mb-3">
            <i className="ri-file-list-3-line text-3xl"></i>
          </div>
          <h3 className="text-lg font-medium text-gray-900">No treatment plans</h3>
          <p className="mt-1 text-sm text-gray-500">
            {selectedPatientId 
              ? "This patient doesn't have any treatment plans yet." 
              : "There are no treatment plans in the system yet."}
          </p>
          <Button 
            className="mt-4"
            onClick={() => setShowNewTreatmentDialog(true)}
          >
            Create First Treatment Plan
          </Button>
        </div>
      );
    }
    
    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">ADA Code</TableHead>
            <TableHead className="w-[200px]">Procedure</TableHead>
            <TableHead>Tooth</TableHead>
            <TableHead>Cost</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {treatmentsList.map((treatment) => {
            // Get category color for ADA code if available
            let categoryColor = "bg-gray-100 text-gray-800";
            if (treatment.adaCode) {
              const adaCodeData = adaCodes.find((code: any) => code.code === treatment.adaCode);
              if (adaCodeData) {
                const category = ADA_CATEGORIES.find(cat => cat.id === adaCodeData.category);
                if (category) {
                  categoryColor = category.color;
                }
              }
            }
            
            return (
              <TableRow key={treatment.id}>
                <TableCell>
                  {treatment.adaCode ? (
                    <Badge variant="outline" className={categoryColor}>
                      {treatment.adaCode}
                    </Badge>
                  ) : "-"}
                </TableCell>
                <TableCell className="font-medium">
                  {treatment.type}
                </TableCell>
                <TableCell>
                  {treatment.toothNumber || "-"}
                </TableCell>
                <TableCell>
                  {treatment.cost ? `$${treatment.cost}` : "-"}
                </TableCell>
                <TableCell>
                  <Badge className={
                    treatment.status === "completed" ? "bg-green-100 text-green-800" :
                    treatment.status === "in-progress" ? "bg-blue-100 text-blue-800" :
                    "bg-yellow-100 text-yellow-800"
                  }>
                    {treatment.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSelectedTreatment(treatment)}
                  >
                    <i className="ri-eye-line mr-1"></i>
                    View
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    );
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Treatment Plans</h2>
        <Button 
          className="bg-primary text-white flex items-center"
          onClick={() => setShowNewTreatmentDialog(true)}
        >
          <i className="ri-add-line mr-1"></i>
          New Treatment Plan
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Filter Treatment Plans</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="w-72">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Select Patient
              </label>
              <Select
                value={selectedPatientId?.toString() || ""}
                onValueChange={handlePatientChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All patients" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All patients</SelectItem>
                  {patients && patients.map((patient: any) => (
                    <SelectItem key={patient.id} value={patient.id.toString()}>
                      {patient.firstName} {patient.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-72">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <Select defaultValue="all">
                <SelectTrigger>
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="planned">Planned</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>
            {selectedPatientId 
              ? `Treatment Plans for ${
                  patients?.find((p: any) => p.id === selectedPatientId)?.firstName || ""
                } ${
                  patients?.find((p: any) => p.id === selectedPatientId)?.lastName || ""
                }`
              : "All Treatment Plans"
            }
          </CardTitle>
        </CardHeader>
        <CardContent>
          {selectedPatientId 
            ? (isLoadingTreatments 
                ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                  </div>
                )
                : renderTreatmentsList(treatments || [])
              )
            : renderTreatmentsList([])
          }
        </CardContent>
      </Card>
      
      {/* New Treatment Plan Dialog */}
      <Dialog open={showNewTreatmentDialog} onOpenChange={setShowNewTreatmentDialog}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>New Treatment Plan</DialogTitle>
            <DialogDescription>
              Create a new treatment plan for the patient using ADA procedure codes.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <div className="space-y-4 py-2">
                <FormField
                  control={form.control}
                  name="patientId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Patient</FormLabel>
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => {
                          field.onChange(parseInt(value));
                          setSelectedPatientId(parseInt(value));
                        }}
                        disabled={!!selectedPatientId}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select patient" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {patients && patients.map((patient: any) => (
                            <SelectItem key={patient.id} value={patient.id.toString()}>
                              {patient.firstName} {patient.lastName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <FormItem>
                      <FormLabel>ADA Category</FormLabel>
                      <Select
                        value={selectedCategory || ""}
                        onValueChange={handleCategoryChange}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="">All Categories</SelectItem>
                          {ADA_CATEGORIES.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="adaCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ADA Procedure Code</FormLabel>
                        <Select
                          value={field.value || ""}
                          onValueChange={(value) => {
                            field.onChange(value);
                            handleADACodeChange(value);
                          }}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select code" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="">None</SelectItem>
                            {filteredAdaCodes.map((code: any) => (
                              <SelectItem key={code.code} value={code.code}>
                                {code.code} - {code.description}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Procedure Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter procedure name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="toothNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tooth Number (optional)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="1" 
                            max="32" 
                            placeholder="Enter tooth number" 
                            value={field.value?.toString() || ""}
                            onChange={e => field.onChange(e.target.value ? parseInt(e.target.value) : null)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="cost"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cost (optional)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter cost" 
                            value={field.value || ""}
                            onChange={e => field.onChange(e.target.value || null)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Enter description" 
                          rows={3}
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="planned">Planned</SelectItem>
                          <SelectItem value="in-progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter className="mt-6">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setShowNewTreatmentDialog(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Save Treatment Plan</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* View Treatment Dialog */}
      {selectedTreatment && (
        <Dialog open={!!selectedTreatment} onOpenChange={() => setSelectedTreatment(null)}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Treatment Details</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium text-gray-500">Patient</h4>
                <p className="text-base">
                  {patients?.find((p: any) => p.id === selectedTreatment.patientId)?.firstName || ""}{" "}
                  {patients?.find((p: any) => p.id === selectedTreatment.patientId)?.lastName || ""}
                </p>
              </div>
              
              {selectedTreatment.adaCode && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500">ADA Procedure Code</h4>
                  <p className="text-base">{selectedTreatment.adaCode}</p>
                </div>
              )}
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Procedure</h4>
                <p className="text-base">{selectedTreatment.type}</p>
              </div>
              
              {selectedTreatment.toothNumber && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Tooth Number</h4>
                  <p className="text-base">{selectedTreatment.toothNumber}</p>
                </div>
              )}
              
              {selectedTreatment.surfaces && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Surfaces</h4>
                  <p className="text-base">{selectedTreatment.surfaces}</p>
                </div>
              )}
              
              {selectedTreatment.cost && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Cost</h4>
                  <p className="text-base">${selectedTreatment.cost}</p>
                </div>
              )}
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Status</h4>
                <Badge className={
                  selectedTreatment.status === "completed" ? "bg-green-100 text-green-800" :
                  selectedTreatment.status === "in-progress" ? "bg-blue-100 text-blue-800" :
                  "bg-yellow-100 text-yellow-800"
                }>
                  {selectedTreatment.status}
                </Badge>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Description</h4>
                <p className="text-base whitespace-pre-wrap">{selectedTreatment.description}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Created</h4>
                <p className="text-base">{format(new Date(selectedTreatment.createdAt), "MMM d, yyyy")}</p>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default TreatmentPlans;