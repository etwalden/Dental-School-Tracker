import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StatsCard from "@/components/dashboard/StatsCard";
import AppointmentList from "@/components/dashboard/AppointmentList";
import TreatmentInsights from "@/components/dashboard/TreatmentInsights";
import DentalChartPreview from "@/components/dashboard/DentalChartPreview";
import { useQuery } from "@tanstack/react-query";

const Dashboard = () => {
  const [timeRange, setTimeRange] = useState("week");
  
  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats", { range: timeRange }],
  });
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Dashboard</h2>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </span>
          <button className="p-2 rounded-md hover:bg-white">
            <i className="ri-calendar-line text-gray-500"></i>
          </button>
          <Select
            value={timeRange}
            onValueChange={(value) => setTimeRange(value)}
          >
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Select range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">Last 3 Months</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Today's Appointments"
          value={stats?.appointments || 8}
          icon="calendar-check"
          iconColor="primary"
          trend={{
            value: "12%",
            label: "vs last week",
            isPositive: true,
          }}
        />
        
        <StatsCard
          title="Pending Records"
          value={stats?.pendingRecords || 5}
          icon="timer"
          iconColor="warning"
          trend={{
            value: "3",
            label: "need attention",
            isPositive: false,
          }}
        />
        
        <StatsCard
          title="New Patients"
          value={stats?.newPatients || 12}
          icon="user-add"
          iconColor="secondary"
          trend={{
            value: "18%",
            label: "this month",
            isPositive: true,
          }}
        />
        
        <StatsCard
          title="AI Suggestions"
          value={stats?.aiSuggestions || 7}
          icon="brain"
          iconColor="purple"
          trend={{
            value: "New",
            label: "treatment insights",
            isPositive: true,
          }}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Appointments */}
        <AppointmentList />
        
        {/* AI Treatment Insights */}
        <TreatmentInsights />
      </div>
      
      {/* Dental Chart Preview */}
      <DentalChartPreview />
    </div>
  );
};

export default Dashboard;
