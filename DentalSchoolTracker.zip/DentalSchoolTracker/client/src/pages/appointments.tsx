import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage, useFormField } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertAppointmentSchema, type InsertAppointment } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { format, addMinutes } from "date-fns";
import { useAuth } from "@/lib/auth";

const AppointmentCalendarView = () => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [appointmentType, setAppointmentType] = useState<string>("all");
  const [showNewAppointmentDialog, setShowNewAppointmentDialog] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  
  const { data: appointments, isLoading } = useQuery({
    queryKey: ["/api/appointments", { date: date?.toISOString() }],
  });
  
  const { data: patients, isLoading: isLoadingPatients } = useQuery({
    queryKey: ["/api/patients"],
  });
  
  const form = useForm<InsertAppointment>({
    resolver: zodResolver(insertAppointmentSchema),
    defaultValues: {
      patientId: 0,
      doctorId: user?.id || 0,
      date: new Date(),
      duration: 30,
      type: "check-up",
      notes: "",
      status: "scheduled",
    },
  });
  
  const onSubmit = async (data: InsertAppointment) => {
    try {
      await apiRequest("POST", "/api/appointments", data);
      
      toast({
        title: "Appointment created",
        description: "The appointment has been successfully scheduled.",
      });
      
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      
      // Close dialog
      setShowNewAppointmentDialog(false);
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem creating the appointment.",
        variant: "destructive",
      });
    }
  };
  
  const filteredAppointments = appointmentType === "all" 
    ? appointments 
    : appointments?.filter((app: any) => app.type === appointmentType);
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Appointments</h2>
        <Button 
          onClick={() => setShowNewAppointmentDialog(true)}
          className="bg-primary text-white flex items-center"
        >
          <i className="ri-add-line mr-1"></i>
          New Appointment
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Select Date</CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border"
            />
            
            <div className="mt-4">
              <FormLabel>Filter by Type</FormLabel>
              <Select
                value={appointmentType}
                onValueChange={setAppointmentType}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="check-up">Check-up</SelectItem>
                  <SelectItem value="cleaning">Cleaning</SelectItem>
                  <SelectItem value="root canal">Root Canal</SelectItem>
                  <SelectItem value="consultation">Consultation</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">
              Appointments for {date ? format(date, "MMMM d, yyyy") : "Today"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
                <p className="mt-2 text-gray-500">Loading appointments...</p>
              </div>
            ) : filteredAppointments && filteredAppointments.length > 0 ? (
              filteredAppointments.map((appointment: any) => {
                const patient = patients?.find((p: any) => p.id === appointment.patientId);
                const startTime = new Date(appointment.date);
                const endTime = addMinutes(startTime, appointment.duration);
                
                return (
                  <div key={appointment.id} className="border rounded-md p-4 hover:bg-gray-50">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center mb-1">
                          <h3 className="font-medium">{patient?.firstName} {patient?.lastName}</h3>
                          <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                            appointment.type === 'check-up' ? 'bg-blue-100 text-blue-700' :
                            appointment.type === 'cleaning' ? 'bg-green-100 text-green-700' :
                            appointment.type === 'root canal' ? 'bg-red-100 text-red-700' :
                            appointment.type === 'consultation' ? 'bg-purple-100 text-purple-700' :
                            'bg-gray-100 text-gray-700'
                          }`}>
                            {appointment.type}
                          </span>
                        </div>
                        <p className="text-sm text-gray-500">
                          {format(startTime, "h:mm a")} - {format(endTime, "h:mm a")}
                        </p>
                        {appointment.notes && (
                          <p className="text-sm text-gray-600 mt-2">{appointment.notes}</p>
                        )}
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <i className="ri-pencil-line mr-1"></i>
                          Edit
                        </Button>
                        <Button variant="destructive" size="sm">
                          <i className="ri-close-line mr-1"></i>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="text-center py-8">
                <div className="text-gray-400 mb-3">
                  <i className="ri-calendar-line text-3xl"></i>
                </div>
                <h3 className="text-lg font-medium text-gray-900">No appointments</h3>
                <p className="mt-1 text-sm text-gray-500">
                  There are no appointments scheduled for this date.
                </p>
                <Button 
                  className="mt-4"
                  onClick={() => setShowNewAppointmentDialog(true)}
                >
                  Schedule an appointment
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <Dialog open={showNewAppointmentDialog} onOpenChange={setShowNewAppointmentDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Schedule New Appointment</DialogTitle>
            <DialogDescription>
              Fill in the details below to schedule a new appointment.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="patientId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Patient</FormLabel>
                    <Select
                      value={field.value.toString()}
                      onValueChange={(value) => field.onChange(parseInt(value))}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select patient" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {patients && patients.map((patient: any) => (
                          <SelectItem key={patient.id} value={patient.id.toString()}>
                            {patient.firstName} {patient.lastName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date & Time</FormLabel>
                      <FormControl>
                        <Input
                          type="datetime-local"
                          value={field.value instanceof Date ? format(field.value, "yyyy-MM-dd'T'HH:mm") : ""}
                          onChange={(e) => field.onChange(new Date(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration (minutes)</FormLabel>
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select duration" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="15">15 minutes</SelectItem>
                          <SelectItem value="30">30 minutes</SelectItem>
                          <SelectItem value="45">45 minutes</SelectItem>
                          <SelectItem value="60">1 hour</SelectItem>
                          <SelectItem value="90">1.5 hours</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Appointment Type</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="check-up">Check-up</SelectItem>
                        <SelectItem value="cleaning">Cleaning</SelectItem>
                        <SelectItem value="root canal">Root Canal</SelectItem>
                        <SelectItem value="consultation">Consultation</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add any additional notes about this appointment"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowNewAppointmentDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-primary">
                  Schedule Appointment
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AppointmentCalendarView;
