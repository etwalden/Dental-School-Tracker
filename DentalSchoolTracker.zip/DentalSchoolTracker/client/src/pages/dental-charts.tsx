import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import DentalChart, { ToothStatus, ToothSurface, ToothTreatment, DentalChartData } from "@/components/ui/dental-chart";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";

// Types
type ToothNote = {
  toothId: number;
  note: string;
};

const DentalCharts = () => {
  const [location] = useLocation();
  const [selectedPatientId, setSelectedPatientId] = useState<number | null>(null);
  const [chartData, setChartData] = useState<DentalChartData | null>(null);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);
  const [toothNotes, setToothNotes] = useState<ToothNote[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Extract patientId from URL if present
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const patientId = params.get('patientId');
    if (patientId) {
      setSelectedPatientId(parseInt(patientId));
    }
  }, [location]);
  
  // Get patients
  const { data: patients } = useQuery({
    queryKey: ["/api/patients"],
  });
  
  // Get patient's dental chart
  const { data: existingChart, isLoading: isLoadingChart } = useQuery({
    queryKey: ["/api/dental-charts/patient", selectedPatientId],
    enabled: !!selectedPatientId,
  });
  
  // Initialize chart data
  useEffect(() => {
    if (existingChart) {
      setChartData(existingChart.data);
      setIsEditing(true);
    } else if (selectedPatientId && !isLoadingChart) {
      // Create new chart data
      const initialData: DentalChartData = {
        upperTeeth: Array.from({ length: 16 }, (_, i) => ({
          id: i + 1,
          status: "healthy" as ToothStatus,
          notes: "",
          treatments: [],
          surfaces: {
            mesial: "healthy",
            occlusal: "healthy",
            distal: "healthy",
            buccal: "healthy",
            lingual: "healthy"
          } as Record<ToothSurface, ToothStatus>,
        })),
        lowerTeeth: Array.from({ length: 16 }, (_, i) => ({
          id: i + 17,
          status: "healthy" as ToothStatus,
          notes: "",
          treatments: [],
          surfaces: {
            mesial: "healthy",
            occlusal: "healthy",
            distal: "healthy",
            buccal: "healthy",
            lingual: "healthy"
          } as Record<ToothSurface, ToothStatus>,
        })),
      };
      
      setChartData(initialData);
      setIsEditing(false);
    }
  }, [existingChart, selectedPatientId, isLoadingChart]);
  
  const handlePatientChange = (patientId: string) => {
    setSelectedPatientId(parseInt(patientId));
    setSelectedTooth(null);
    setToothNotes([]);
    queryClient.invalidateQueries({ queryKey: ["/api/dental-charts/patient"] });
  };
  
  const handleToothClick = (toothId: number, currentStatus: ToothStatus) => {
    if (!chartData) return;
    
    setSelectedTooth(toothId);
    
    // Find if there's a note for this tooth
    const existingNote = toothNotes.find(n => n.toothId === toothId);
    
    // When the user clicks on a tooth in the chart component, we update UI to show that tooth's details
    // Note: The actual tooth status update is now handled within the dental chart component
    // This function is now mainly for handling UI state in the dental charts page
  };
  
  const handleSaveToothNote = (note: string) => {
    if (!selectedTooth) return;
    
    // Update the notes array
    const existingNoteIndex = toothNotes.findIndex(n => n.toothId === selectedTooth);
    
    if (existingNoteIndex >= 0) {
      const updatedNotes = [...toothNotes];
      updatedNotes[existingNoteIndex] = { ...updatedNotes[existingNoteIndex], note };
      setToothNotes(updatedNotes);
    } else {
      setToothNotes([...toothNotes, { toothId: selectedTooth, note }]);
    }
    
    // Update the chart data with the note
    if (chartData) {
      const section = selectedTooth <= 16 ? "upperTeeth" : "lowerTeeth";
      const toothIndex = section === "upperTeeth" ? selectedTooth - 1 : selectedTooth - 17;
      
      const updatedChartData = { ...chartData };
      updatedChartData[section][toothIndex].notes = note;
      setChartData(updatedChartData);
    }
  };
  
  const handleSaveChart = async () => {
    if (!user || !selectedPatientId || !chartData) {
      toast({
        title: "Error",
        description: "Missing required information to save chart",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const payload = {
        patientId: selectedPatientId,
        lastUpdatedBy: user.id,
        data: chartData,
      };
      
      if (isEditing && existingChart) {
        // Update existing chart
        await apiRequest("PATCH", `/api/dental-charts/${existingChart.id}`, payload);
        toast({
          title: "Success",
          description: "Dental chart has been updated",
        });
      } else {
        // Create new chart
        await apiRequest("POST", "/api/dental-charts", payload);
        toast({
          title: "Success",
          description: "Dental chart has been created",
        });
      }
      
      // Log audit
      await apiRequest("POST", "/api/audit-logs", {
        userId: user.id,
        action: isEditing ? "update" : "create",
        resourceType: "dental-chart",
        resourceId: isEditing ? existingChart.id.toString() : "new",
        details: `User ${isEditing ? "updated" : "created"} dental chart for patient ${selectedPatientId}`,
      });
      
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/dental-charts"] });
      
      setShowSaveDialog(false);
      setIsEditing(true);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save dental chart",
        variant: "destructive",
      });
    }
  };
  
  const handleRequestAISuggestions = async () => {
    if (!selectedPatientId || !chartData) {
      toast({
        title: "Error",
        description: "Please select a patient and complete the chart first",
        variant: "destructive",
      });
      return;
    }
    
    try {
      await apiRequest("POST", "/api/ai-suggestions/generate-from-chart", {
        patientId: selectedPatientId,
        chartData,
      });
      
      toast({
        title: "Success",
        description: "AI treatment suggestions have been generated",
      });
      
      // Invalidate AI suggestions
      queryClient.invalidateQueries({ queryKey: ["/api/ai-suggestions"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate AI suggestions",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Dental Charts</h2>
        <div className="flex space-x-2">
          {chartData && (
            <>
              <Button 
                variant="outline" 
                className="flex items-center"
                onClick={handleRequestAISuggestions}
              >
                <i className="ri-robot-line mr-1"></i>
                Get AI Suggestions
              </Button>
              <Button 
                className="bg-primary text-white flex items-center"
                onClick={() => setShowSaveDialog(true)}
              >
                <i className="ri-save-line mr-1"></i>
                Save Chart
              </Button>
            </>
          )}
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Patient Selection</CardTitle>
        </CardHeader>
        <CardContent>
          <Select
            value={selectedPatientId?.toString() || ""}
            onValueChange={handlePatientChange}
          >
            <SelectTrigger className="w-full sm:w-72">
              <SelectValue placeholder="Select a patient" />
            </SelectTrigger>
            <SelectContent>
              {patients && patients.map((patient: any) => (
                <SelectItem key={patient.id} value={patient.id.toString()}>
                  {patient.firstName} {patient.lastName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>
      
      {selectedPatientId ? (
        isLoadingChart ? (
          <div className="flex justify-center items-center h-40">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Dental Chart</CardTitle>
                </CardHeader>
                <CardContent>
                  {chartData ? (
                    <DentalChart 
                      data={chartData} 
                      editable={true}
                      onToothClick={handleToothClick}
                    />
                  ) : (
                    <div className="text-center py-8">
                      <div className="text-gray-400 mb-3">
                        <i className="ri-teeth-line text-3xl"></i>
                      </div>
                      <h3 className="text-lg font-medium text-gray-900">No chart data</h3>
                      <p className="mt-1 text-sm text-gray-500">
                        There was a problem loading the chart data.
                      </p>
                    </div>
                  )}
                  
                  <div className="mt-6">
                    <h3 className="text-sm font-medium mb-2">Instructions</h3>
                    <p className="text-sm text-gray-500">
                      Click on a tooth to view its details. Click on specific surfaces to mark treatments. The colors indicate the status:
                    </p>
                    <div className="flex flex-wrap gap-2 mt-2 text-xs">
                      <div className="flex items-center px-2 py-1 bg-white rounded border">
                        <span className="w-3 h-3 bg-white border border-gray-300 rounded-sm mr-1"></span>
                        <span>Healthy</span>
                      </div>
                      <div className="flex items-center px-2 py-1 bg-white rounded border">
                        <span className="w-3 h-3 bg-[#00A896] rounded-sm mr-1"></span>
                        <span>Treated</span>
                      </div>
                      <div className="flex items-center px-2 py-1 bg-white rounded border">
                        <span className="w-3 h-3 bg-[#FF6B6B] rounded-sm mr-1"></span>
                        <span>Needs Treatment</span>
                      </div>
                      <div className="flex items-center px-2 py-1 bg-white rounded border">
                        <span className="w-3 h-3 border border-[#FF6B6B] rounded-sm mr-1 relative">
                          <span className="absolute inset-0 flex items-center justify-center text-[8px] text-[#FF6B6B]">X</span>
                        </span>
                        <span>Missing</span>
                      </div>
                      <div className="flex items-center px-2 py-1 bg-white rounded border">
                        <span className="w-3 h-3 bg-[#B0B0B0] rounded-sm mr-1"></span>
                        <span>Crown</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-500 mt-2">
                      Tooth surfaces: Click on a specific surface (mesial, occlusal, distal, buccal, lingual) to mark treatments on that area only.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>
                    {selectedTooth 
                      ? `Tooth #${selectedTooth} Details` 
                      : "Tooth Details"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedTooth ? (
                    <>
                      <div className="mb-4">
                        <div className="flex items-center space-x-2 mb-2">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                            chartData && (() => {
                              const section = selectedTooth <= 16 ? "upperTeeth" : "lowerTeeth";
                              const toothIndex = selectedTooth <= 16 ? selectedTooth - 1 : selectedTooth - 17;
                              const status = chartData[section][toothIndex].status;
                              
                              switch(status) {
                                case "healthy": return "bg-white border border-gray-300";
                                case "treated": return "bg-[#00A896] text-white";
                                case "needs-treatment": return "bg-[#FF6B6B] text-white";
                                case "missing": return "bg-white border border-[#FF6B6B] text-[#FF6B6B]";
                                case "crown": return "bg-[#B0B0B0] text-white";
                                case "implant": return "bg-[#A0A0A0] text-white";
                                case "bridge": return "bg-[#C0C0C0] text-white";
                                default: return "bg-white border border-gray-300";
                              }
                            })()
                          }`}>
                            {selectedTooth}
                          </div>
                          <span className="font-medium">
                            {chartData && (() => {
                              const section = selectedTooth <= 16 ? "upperTeeth" : "lowerTeeth";
                              const toothIndex = selectedTooth <= 16 ? selectedTooth - 1 : selectedTooth - 17;
                              const status = chartData[section][toothIndex].status;
                              
                              switch(status) {
                                case "healthy": return "Healthy";
                                case "treated": return "Treated";
                                case "needs-treatment": return "Needs Treatment";
                                case "missing": return "Missing";
                                case "crown": return "Crown";
                                case "implant": return "Implant";
                                case "bridge": return "Bridge";
                                default: return "Unknown";
                              }
                            })()}
                          </span>
                        </div>
                        
                        <div className="space-y-3">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Tooth Surfaces
                            </label>
                            {chartData && (() => {
                              const section = selectedTooth <= 16 ? "upperTeeth" : "lowerTeeth";
                              const toothIndex = selectedTooth <= 16 ? selectedTooth - 1 : selectedTooth - 17;
                              const surfaces = chartData[section][toothIndex].surfaces || {};
                              
                              return (
                                <div className="grid grid-cols-3 gap-2 p-2 bg-gray-50 rounded border mb-4">
                                  <div className="text-center">
                                    <div className={`mx-auto w-8 h-8 rounded flex items-center justify-center text-xs mb-1 ${
                                      surfaces.buccal === "healthy" ? "bg-white border border-gray-300" :
                                      surfaces.buccal === "treated" ? "bg-[#00A896] text-white" :
                                      surfaces.buccal === "needs-treatment" ? "bg-[#FF6B6B] text-white" : 
                                      "bg-white border border-gray-300"
                                    }`}>B</div>
                                    <span className="text-xs">Buccal</span>
                                  </div>
                                  <div className="text-center">
                                    <div className={`mx-auto w-8 h-8 rounded flex items-center justify-center text-xs mb-1 ${
                                      surfaces.occlusal === "healthy" ? "bg-white border border-gray-300" :
                                      surfaces.occlusal === "treated" ? "bg-[#00A896] text-white" :
                                      surfaces.occlusal === "needs-treatment" ? "bg-[#FF6B6B] text-white" : 
                                      "bg-white border border-gray-300"
                                    }`}>O</div>
                                    <span className="text-xs">Occlusal</span>
                                  </div>
                                  <div className="text-center">
                                    <div className={`mx-auto w-8 h-8 rounded flex items-center justify-center text-xs mb-1 ${
                                      surfaces.lingual === "healthy" ? "bg-white border border-gray-300" :
                                      surfaces.lingual === "treated" ? "bg-[#00A896] text-white" :
                                      surfaces.lingual === "needs-treatment" ? "bg-[#FF6B6B] text-white" : 
                                      "bg-white border border-gray-300"
                                    }`}>L</div>
                                    <span className="text-xs">Lingual</span>
                                  </div>
                                  <div className="text-center">
                                    <div className={`mx-auto w-8 h-8 rounded flex items-center justify-center text-xs mb-1 ${
                                      surfaces.mesial === "healthy" ? "bg-white border border-gray-300" :
                                      surfaces.mesial === "treated" ? "bg-[#00A896] text-white" :
                                      surfaces.mesial === "needs-treatment" ? "bg-[#FF6B6B] text-white" : 
                                      "bg-white border border-gray-300"
                                    }`}>M</div>
                                    <span className="text-xs">Mesial</span>
                                  </div>
                                  <div className="text-center">
                                    <div className="mx-auto w-8 h-8 rounded flex items-center justify-center text-xs mb-1 border border-dashed border-gray-300">
                                      {selectedTooth}
                                    </div>
                                    <span className="text-xs">Tooth</span>
                                  </div>
                                  <div className="text-center">
                                    <div className={`mx-auto w-8 h-8 rounded flex items-center justify-center text-xs mb-1 ${
                                      surfaces.distal === "healthy" ? "bg-white border border-gray-300" :
                                      surfaces.distal === "treated" ? "bg-[#00A896] text-white" :
                                      surfaces.distal === "needs-treatment" ? "bg-[#FF6B6B] text-white" : 
                                      "bg-white border border-gray-300"
                                    }`}>D</div>
                                    <span className="text-xs">Distal</span>
                                  </div>
                                </div>
                              );
                            })()}
                            
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Notes for Tooth #{selectedTooth}
                            </label>
                            <Textarea
                              placeholder="Add notes about this tooth..."
                              value={
                                chartData && chartData[selectedTooth <= 16 ? "upperTeeth" : "lowerTeeth"][
                                  selectedTooth <= 16 ? selectedTooth - 1 : selectedTooth - 17
                                ].notes || ""
                              }
                              onChange={(e) => handleSaveToothNote(e.target.value)}
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Add Treatment
                            </label>
                            <div className="flex space-x-2">
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select treatment" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="filling">Filling</SelectItem>
                                  <SelectItem value="crown">Crown</SelectItem>
                                  <SelectItem value="root-canal">Root Canal</SelectItem>
                                  <SelectItem value="extraction">Extraction</SelectItem>
                                  <SelectItem value="cleaning">Cleaning</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <Button size="sm">Add</Button>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <Accordion type="single" collapsible className="border rounded-md">
                        <AccordionItem value="treatments">
                          <AccordionTrigger className="px-4">
                            Planned Treatments
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-4">
                            <div className="text-center py-2 text-sm text-gray-500">
                              No treatments planned for this tooth
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="history">
                          <AccordionTrigger className="px-4">
                            Treatment History
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-4">
                            <div className="text-center py-2 text-sm text-gray-500">
                              No treatment history for this tooth
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <div className="text-gray-400 mb-3">
                        <i className="ri-cursor-line text-3xl"></i>
                      </div>
                      <h3 className="text-lg font-medium text-gray-900">No tooth selected</h3>
                      <p className="mt-1 text-sm text-gray-500">
                        Click on a tooth in the chart to view and edit its details
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Chart Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  {chartData && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Healthy Teeth:</span>
                          <span className="font-medium">
                            {chartData.upperTeeth.filter(t => t.status === "healthy").length +
                              chartData.lowerTeeth.filter(t => t.status === "healthy").length}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Treated Teeth:</span>
                          <span className="font-medium">
                            {chartData.upperTeeth.filter(t => t.status === "treated").length +
                              chartData.lowerTeeth.filter(t => t.status === "treated").length}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Teeth Needing Treatment:</span>
                          <span className="font-medium text-accent">
                            {chartData.upperTeeth.filter(t => t.status === "needs-treatment").length +
                              chartData.lowerTeeth.filter(t => t.status === "needs-treatment").length}
                          </span>
                        </div>
                      </div>
                      
                      <Separator className="my-4" />
                      
                      <div className="text-sm">
                        <div className="font-medium mb-1">Teeth Needing Attention:</div>
                        {(chartData.upperTeeth.some(t => t.status === "needs-treatment") || 
                          chartData.lowerTeeth.some(t => t.status === "needs-treatment")) ? (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {chartData.upperTeeth
                              .filter(t => t.status === "needs-treatment")
                              .map(t => (
                                <div key={t.id} className="bg-accent text-white text-xs px-2 py-1 rounded">
                                  #{t.id}
                                </div>
                              ))}
                            {chartData.lowerTeeth
                              .filter(t => t.status === "needs-treatment")
                              .map(t => (
                                <div key={t.id} className="bg-accent text-white text-xs px-2 py-1 rounded">
                                  #{t.id}
                                </div>
                              ))}
                          </div>
                        ) : (
                          <p className="text-sm text-gray-500">
                            No teeth need immediate attention
                          </p>
                        )}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )
      ) : (
        <Card>
          <CardContent className="text-center py-10">
            <div className="text-gray-400 mb-3">
              <i className="ri-teeth-line text-4xl"></i>
            </div>
            <h3 className="text-lg font-medium text-gray-900">No patient selected</h3>
            <p className="mt-1 text-sm text-gray-500">
              Please select a patient to create or edit their dental chart
            </p>
          </CardContent>
        </Card>
      )}
      
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Dental Chart</DialogTitle>
            <DialogDescription>
              You are about to {isEditing ? "update" : "save"} the dental chart for this patient.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Additional Notes (Optional)
              </label>
              <Textarea 
                placeholder="Add any additional notes about the chart..."
              />
            </div>
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 text-sm text-yellow-800">
              <div className="flex items-start">
                <i className="ri-information-line mr-2 mt-0.5"></i>
                <div>
                  <p className="font-medium">HIPAA Compliance Notice</p>
                  <p className="mt-1">
                    This dental chart is part of the patient's protected health information (PHI).
                    By saving this chart, you acknowledge that it will be stored securely in accordance
                    with HIPAA regulations.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
              Cancel
            </Button>
            <Button 
              className="bg-primary" 
              onClick={handleSaveChart}
            >
              {isEditing ? "Update Chart" : "Save Chart"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DentalCharts;
