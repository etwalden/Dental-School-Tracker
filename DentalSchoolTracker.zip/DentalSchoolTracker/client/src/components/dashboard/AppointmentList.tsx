import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Appointment, Patient, User } from "@shared/schema";

interface AppointmentItemProps {
  appointment: Appointment;
  patient: Patient;
  doctor: User;
}

const AppointmentItem = ({ appointment, patient, doctor }: AppointmentItemProps) => {
  // Extract time from appointment date
  const appointmentTime = new Date(appointment.date);
  const formattedTime = format(appointmentTime, "h:mm a");
  
  // Determine badge color based on appointment type
  const getBadgeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'check-up':
        return 'bg-blue-100 text-primary';
      case 'cleaning':
        return 'bg-green-100 text-green-700';
      case 'root canal':
        return 'bg-red-100 text-red-700';
      case 'consultation':
        return 'bg-purple-100 text-purple-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };
  
  return (
    <div className="p-4 hover:bg-gray-50 transition-colors flex items-center border-b border-gray-200 last:border-0">
      <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-primary font-semibold">
        {formattedTime}
      </div>
      <div className="ml-4">
        <h4 className="font-medium">{patient.firstName} {patient.lastName}</h4>
        <div className="flex items-center text-sm text-gray-500">
          <span className={`${getBadgeColor(appointment.type)} text-xs px-2 py-0.5 rounded mr-2`}>
            {appointment.type}
          </span>
          <span>Dr. {doctor.firstName} {doctor.lastName}</span>
        </div>
      </div>
      <div className="ml-auto flex space-x-2">
        <Link href={`/clinical-notes?patientId=${patient.id}`}>
          <button className="p-2 rounded-md hover:bg-gray-100 text-gray-500">
            <i className="ri-file-text-line"></i>
          </button>
        </Link>
        <button className="p-2 rounded-md hover:bg-gray-100 text-gray-500">
          <i className="ri-message-2-line"></i>
        </button>
        <Button className="bg-primary text-white px-3 py-1 rounded-md text-sm">
          Start
        </Button>
      </div>
    </div>
  );
};

const AppointmentList = () => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const { data: appointments, isLoading: isLoadingAppointments } = useQuery({
    queryKey: ["/api/appointments", { from: today.toISOString() }],
  });

  const { data: patients, isLoading: isLoadingPatients } = useQuery({
    queryKey: ["/api/patients"],
  });

  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
  });

  const isLoading = isLoadingAppointments || isLoadingPatients || isLoadingUsers;

  return (
    <Card className="lg:col-span-2">
      <CardHeader className="border-b border-gray-200 flex flex-row items-center justify-between p-4">
        <CardTitle className="text-base font-semibold">Today's Appointments</CardTitle>
        <Link href="/appointments">
          <Button variant="link" className="text-primary text-sm hover:underline flex items-center">
            View All <i className="ri-arrow-right-s-line ml-1"></i>
          </Button>
        </Link>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <>
            {[...Array(4)].map((_, i) => (
              <div key={i} className="p-4 border-b border-gray-200 last:border-0">
                <div className="flex items-center">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="ml-4 space-y-2">
                    <Skeleton className="h-4 w-40" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                  <div className="ml-auto flex space-x-2">
                    <Skeleton className="h-8 w-8 rounded-md" />
                    <Skeleton className="h-8 w-8 rounded-md" />
                    <Skeleton className="h-8 w-16 rounded-md" />
                  </div>
                </div>
              </div>
            ))}
          </>
        ) : appointments && appointments.length > 0 ? (
          <div className="divide-y divide-gray-200">
            {appointments.map((appointment: Appointment) => {
              const patient = patients?.find((p: Patient) => p.id === appointment.patientId);
              const doctor = users?.find((u: User) => u.id === appointment.doctorId);
              
              if (!patient || !doctor) return null;
              
              return (
                <AppointmentItem 
                  key={appointment.id}
                  appointment={appointment}
                  patient={patient}
                  doctor={doctor}
                />
              );
            })}
          </div>
        ) : (
          <div className="p-8 text-center">
            <div className="text-gray-400 mb-2">
              <i className="ri-calendar-line text-3xl"></i>
            </div>
            <h3 className="text-lg font-medium text-gray-900">No appointments today</h3>
            <p className="mt-1 text-sm text-gray-500">
              There are no appointments scheduled for today.
            </p>
            <Link href="/appointments">
              <Button className="mt-4">Schedule an appointment</Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AppointmentList;
