import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import AISuggestion from "@/components/ui/ai-suggestion";
import { Button } from "@/components/ui/button";
import { AiSuggestion } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

const TreatmentInsights = () => {
  const { toast } = useToast();
  
  const { data: suggestions, isLoading } = useQuery({
    queryKey: ["/api/ai-suggestions"],
  });

  const handleRefresh = async () => {
    try {
      await apiRequest("POST", "/api/ai-suggestions/generate", {});
      await queryClient.invalidateQueries({ queryKey: ["/api/ai-suggestions"] });
      toast({
        title: "Insights refreshed",
        description: "AI treatment insights have been updated",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to refresh AI insights",
        variant: "destructive",
      });
    }
  };

  const handleAddToNotes = async (content: string) => {
    toast({
      title: "Added to notes",
      description: "Suggestion has been added to clinical notes",
    });
  };

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 right-0 w-20 h-20">
        <div className="bg-accent text-white text-xs font-semibold py-1 px-4 shadow-md rotate-45 transform translate-y-3 translate-x-6">
          AI Powered
        </div>
      </div>
      <CardHeader className="border-b border-gray-200 flex flex-row items-center justify-between p-4">
        <CardTitle className="text-base font-semibold">AI Treatment Insights</CardTitle>
        <Button 
          variant="ghost" 
          size="sm"
          className="text-accent text-sm hover:underline"
          onClick={handleRefresh}
        >
          Refresh
        </Button>
      </CardHeader>
      <CardContent className="p-4 space-y-4">
        {isLoading ? (
          <>
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-gray-50 p-3 rounded-md border border-gray-200">
                <div className="flex items-center">
                  <Skeleton className="w-8 h-8 rounded-full" />
                  <div className="ml-3 space-y-1">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
                <Skeleton className="mt-2 h-12 w-full" />
                <div className="mt-2 flex justify-end space-x-2">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-6 w-20" />
                </div>
              </div>
            ))}
          </>
        ) : suggestions && suggestions.length > 0 ? (
          suggestions.map((suggestion: AiSuggestion) => (
            <AISuggestion 
              key={suggestion.id}
              suggestion={suggestion}
              onAddToNotes={handleAddToNotes}
            />
          ))
        ) : (
          <div className="text-center py-6">
            <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-3">
              <i className="ri-brain-line text-purple-500 text-xl"></i>
            </div>
            <h3 className="text-base font-medium text-gray-900">No AI insights available</h3>
            <p className="mt-1 text-sm text-gray-500">
              Refresh to generate new treatment insights based on patient records.
            </p>
            <Button 
              variant="outline" 
              size="sm"
              className="mt-4"
              onClick={handleRefresh}
            >
              Generate Insights
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TreatmentInsights;
