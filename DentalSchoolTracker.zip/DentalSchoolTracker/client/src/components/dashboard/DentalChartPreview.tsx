import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import DentalChart, { DentalChartData } from "@/components/ui/dental-chart";
import { formatDistanceToNow } from "date-fns";
import { DentalChart as DentalChartType, Patient } from "@shared/schema";

interface PatientCardProps {
  patient: Patient;
  lastUpdated: string;
  onClick: () => void;
}

const PatientCard = ({ patient, lastUpdated, onClick }: PatientCardProps) => {
  return (
    <div className="flex-1 p-2 bg-gray-50 rounded-md border border-gray-200 flex items-center">
      <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
        <span className="text-white font-medium">
          {patient.firstName.charAt(0)}{patient.lastName.charAt(0)}
        </span>
      </div>
      <div className="ml-3">
        <h4 className="text-sm font-medium">{patient.firstName} {patient.lastName}</h4>
        <p className="text-xs text-gray-500">
          Updated {formatDistanceToNow(new Date(lastUpdated), { addSuffix: true })}
        </p>
      </div>
      <Button 
        variant="link" 
        className="ml-auto text-primary"
        onClick={onClick}
      >
        View
      </Button>
    </div>
  );
};

const DentalChartPreview = () => {
  const { data: dentalCharts, isLoading: isLoadingCharts } = useQuery({
    queryKey: ["/api/dental-charts/recent"],
  });

  const { data: patients, isLoading: isLoadingPatients } = useQuery({
    queryKey: ["/api/patients"],
  });

  const isLoading = isLoadingCharts || isLoadingPatients;

  // Get first chart for preview if available
  const firstChart = dentalCharts && dentalCharts.length > 0 ? dentalCharts[0] : null;
  const patientForPreview = firstChart && patients 
    ? patients.find((p: Patient) => p.id === firstChart.patientId)
    : null;

  // Function to convert DB chart data to component format
  const convertChartDataFormat = (chartData: any): DentalChartData => {
    // This would map from the DB format to the component's expected format
    // For simplicity in this example, assuming the JSON data format matches
    return chartData as DentalChartData;
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
      <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-gray-200">
        <CardTitle className="text-base font-semibold">Recent Dental Chart Activity</CardTitle>
        <Link href="/dental-charts">
          <Button variant="link" className="text-primary text-sm hover:underline flex items-center">
            View All Charts <i className="ri-arrow-right-s-line ml-1"></i>
          </Button>
        </Link>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoading ? (
          <>
            <div className="flex items-center space-x-4 mb-4">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="flex-1 h-16" />
              ))}
            </div>
            <Skeleton className="h-60 w-full" />
          </>
        ) : dentalCharts && dentalCharts.length > 0 && patients ? (
          <>
            <div className="flex items-center space-x-4 mb-4">
              {dentalCharts.slice(0, 3).map((chart: DentalChartType) => {
                const patient = patients.find((p: Patient) => p.id === chart.patientId);
                if (!patient) return null;
                
                return (
                  <PatientCard 
                    key={chart.id}
                    patient={patient}
                    lastUpdated={chart.updatedAt}
                    onClick={() => window.location.href = `/dental-charts?patientId=${patient.id}`}
                  />
                );
              })}
            </div>
            
            {firstChart && patientForPreview && (
              <>
                <h4 className="text-sm font-medium mb-2">
                  {patientForPreview.firstName} {patientForPreview.lastName}'s Dental Chart
                </h4>
                <DentalChart 
                  data={convertChartDataFormat(firstChart.data)}
                  editable={false}
                />
              </>
            )}
          </>
        ) : (
          <div className="text-center py-8">
            <div className="text-gray-400 mb-3">
              <i className="ri-teeth-line text-3xl"></i>
            </div>
            <h3 className="text-lg font-medium text-gray-900">No recent charts</h3>
            <p className="mt-1 text-sm text-gray-500">
              There are no recently updated dental charts.
            </p>
            <Link href="/dental-charts">
              <Button className="mt-4">Create a new chart</Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DentalChartPreview;
