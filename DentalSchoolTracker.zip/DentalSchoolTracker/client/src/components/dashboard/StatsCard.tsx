import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconColor: string;
  trend?: {
    value: string;
    label: string;
    isPositive: boolean;
  };
  className?: string;
}

const StatsCard = ({ 
  title, 
  value, 
  icon, 
  iconColor, 
  trend, 
  className 
}: StatsCardProps) => {
  return (
    <div className={cn("bg-white rounded-lg shadow-sm p-4 border border-gray-200", className)}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-500">{title}</p>
          <h3 className="text-2xl font-semibold mt-1">{value}</h3>
        </div>
        <div className={cn(`w-10 h-10 rounded-full flex items-center justify-center`, 
          iconColor === 'primary' && 'bg-blue-100',
          iconColor === 'secondary' && 'bg-green-100', 
          iconColor === 'accent' && 'bg-red-100',
          iconColor === 'warning' && 'bg-yellow-100',
          iconColor === 'purple' && 'bg-purple-100')}>
          <i className={cn(`ri-${icon}-line`, 
            iconColor === 'primary' && 'text-primary',
            iconColor === 'secondary' && 'text-green-500',
            iconColor === 'accent' && 'text-accent',
            iconColor === 'warning' && 'text-yellow-500',
            iconColor === 'purple' && 'text-purple-500')}></i>
        </div>
      </div>
      
      {trend && (
        <div className="mt-4 flex items-center text-xs">
          <span className={cn("flex items-center", 
            trend.isPositive ? "text-green-500" : "text-red-500")}>
            <i className={cn(`ri-arrow-${trend.isPositive ? 'up' : 'down'}-line mr-1`)}></i>
            {trend.value}
          </span>
          <span className="ml-2 text-gray-500">{trend.label}</span>
        </div>
      )}
    </div>
  );
};

export default StatsCard;
