import { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";

interface Message {
  role: "ai" | "user";
  content: string;
  timestamp: Date;
}

const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "ai",
      content: "Hello, I'm your dental AI assistant. How can I help you today?",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  // Scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleToggleChat = () => {
    setIsOpen(!isOpen);
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!inputValue.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      role: "user",
      content: inputValue,
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/ai/chat", {
        message: userMessage.content,
        userId: user?.id
      });
      
      const data = await response.json();
      
      // Add AI response
      const aiMessage: Message = {
        role: "ai",
        content: data.reply,
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      // Add error message
      const errorMessage: Message = {
        role: "ai",
        content: "I'm sorry, I encountered an error. Please try again later.",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-10">
      {isOpen && (
        <Card className="bg-white rounded-lg shadow-lg border border-gray-200 w-80 mb-4">
          <div className="p-3 bg-primary text-white rounded-t-lg flex items-center justify-between">
            <div className="flex items-center">
              <i className="ri-robot-line mr-2"></i>
              <h3 className="font-medium">Dental Assistant AI</h3>
            </div>
            <div className="flex">
              <button
                className="p-1 hover:bg-primary-dark rounded-full"
                onClick={handleToggleChat}
              >
                <i className="ri-subtract-line"></i>
              </button>
              <button
                className="p-1 hover:bg-primary-dark rounded-full ml-1"
                onClick={handleToggleChat}
              >
                <i className="ri-close-line"></i>
              </button>
            </div>
          </div>
          
          <div className="h-80 overflow-y-auto p-3 space-y-3">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex items-start ${
                  message.role === "ai" ? "" : "flex-row-reverse"
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.role === "ai"
                      ? "bg-primary text-white"
                      : "bg-gray-300"
                  }`}
                >
                  {message.role === "ai" ? (
                    <i className="ri-robot-line"></i>
                  ) : (
                    <span className="text-xs font-semibold">
                      {user?.firstName?.[0]}{user?.lastName?.[0]}
                    </span>
                  )}
                </div>
                <div
                  className={`${
                    message.role === "ai"
                      ? "ml-2 bg-gray-100 text-gray-800"
                      : "mr-2 bg-primary text-white"
                  } rounded-lg p-2 max-w-[80%]`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex items-start">
                <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0">
                  <i className="ri-robot-line"></i>
                </div>
                <div className="ml-2 bg-gray-100 rounded-lg p-2 max-w-[80%]">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-4 w-32" />
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
          
          <div className="p-3 border-t border-gray-200">
            <form onSubmit={handleSendMessage} className="flex">
              <Input
                type="text"
                placeholder="Type your question..."
                className="flex-1 rounded-l-md px-3 py-2 text-sm"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                disabled={isLoading}
              />
              <Button
                type="submit"
                className="bg-primary text-white px-3 py-2 rounded-r-md hover:bg-blue-700"
                disabled={isLoading || !inputValue.trim()}
              >
                <i className="ri-send-plane-fill"></i>
              </Button>
            </form>
            <p className="text-xs text-gray-500 mt-1">
              Powered by OpenAI - Not for diagnostic use
            </p>
          </div>
        </Card>
      )}
      
      <Button
        className="bg-primary text-white rounded-full w-14 h-14 shadow-lg flex items-center justify-center hover:bg-blue-700"
        onClick={handleToggleChat}
      >
        <i className="ri-robot-line text-2xl"></i>
      </Button>
    </div>
  );
};

export default AIAssistant;
