import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { AiSuggestion } from "@shared/schema";

interface AISuggestionProps {
  suggestion: AiSuggestion;
  onAddToNotes?: (suggestionContent: string) => void;
  className?: string;
}

const AISuggestion = ({ suggestion, onAddToNotes, className }: AISuggestionProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState<"pending" | "approved" | "dismissed">(
    suggestion.status as "pending" | "approved" | "dismissed"
  );
  const { toast } = useToast();

  const handleDismiss = async () => {
    setIsLoading(true);
    try {
      await apiRequest("PATCH", `/api/ai-suggestions/${suggestion.id}`, {
        status: "dismissed",
      });
      setStatus("dismissed");
      toast({
        title: "Suggestion dismissed",
      });
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/ai-suggestions"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to dismiss suggestion",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToNotes = () => {
    if (onAddToNotes) {
      onAddToNotes(suggestion.content);
    }
    
    // Update suggestion status
    apiRequest("PATCH", `/api/ai-suggestions/${suggestion.id}`, {
      status: "approved",
    }).then(() => {
      setStatus("approved");
      toast({
        title: "Added to notes",
        description: "Suggestion has been added to clinical notes",
      });
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/ai-suggestions"] });
    }).catch(() => {
      toast({
        title: "Error",
        description: "Failed to update suggestion status",
        variant: "destructive",
      });
    });
  };

  if (status === "dismissed") {
    return null;
  }

  return (
    <Card className={cn("mb-4", className)}>
      <CardContent className="p-3">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
            <i className="ri-brain-line text-purple-500"></i>
          </div>
          <div className="ml-3">
            <h4 className="text-sm font-medium">
              {suggestion.patientId 
                ? `Patient ID: ${suggestion.patientId}` 
                : "AI Suggestion"}
            </h4>
            <p className="text-xs text-gray-500">
              Based on {suggestion.basedOn}
            </p>
          </div>
        </div>
        
        <p className="mt-2 text-sm">
          {suggestion.content}
        </p>
        
        <div className="mt-2 flex justify-end space-x-2">
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-gray-500 hover:text-gray-700"
            onClick={handleDismiss}
            disabled={isLoading}
          >
            Dismiss
          </Button>
          
          <Button
            variant="link"
            size="sm"
            className="text-xs text-primary hover:text-primary-dark"
            onClick={handleAddToNotes}
            disabled={isLoading}
          >
            Add to Notes
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AISuggestion;
