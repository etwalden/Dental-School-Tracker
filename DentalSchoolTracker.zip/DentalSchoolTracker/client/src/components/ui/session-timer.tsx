import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from '@/lib/auth';

// Session timeout in minutes
const SESSION_TIMEOUT = 15;
// Warning before timeout in minutes
const WARNING_BEFORE_TIMEOUT = 2;

interface SessionContextType {
  timeRemaining: number;
  resetTimer: () => void;
  logoutUser: () => void;
  showWarning: boolean;
}

const SessionContext = createContext<SessionContextType | undefined>(undefined);

export const SessionTimeoutProvider = ({ children }: { children: ReactNode }) => {
  const [timeRemaining, setTimeRemaining] = useState(SESSION_TIMEOUT * 60); // in seconds
  const [showWarning, setShowWarning] = useState(false);
  const { toast } = useToast();
  const { logout, isAuthenticated } = useAuth();

  const resetTimer = useCallback(() => {
    setTimeRemaining(SESSION_TIMEOUT * 60);
    setShowWarning(false);
  }, []);

  const logoutUser = useCallback(() => {
    logout();
    toast({
      title: "Session Expired",
      description: "Your session has expired due to inactivity. Please log in again.",
      variant: "destructive",
    });
  }, [logout, toast]);

  useEffect(() => {
    if (!isAuthenticated) return;
    
    const timerInterval = setInterval(() => {
      setTimeRemaining((prevTime) => {
        // Calculate warning threshold in seconds
        const warningThreshold = WARNING_BEFORE_TIMEOUT * 60;
        
        if (prevTime <= warningThreshold && !showWarning) {
          setShowWarning(true);
          toast({
            title: "Session Expiring Soon",
            description: `Your session will expire in ${WARNING_BEFORE_TIMEOUT} minutes due to inactivity.`,
            variant: "warning",
          });
        }
        
        // If time is up, logout user
        if (prevTime <= 1) {
          clearInterval(timerInterval);
          logoutUser();
          return 0;
        }
        
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timerInterval);
  }, [isAuthenticated, showWarning, logoutUser, toast]);

  const value = {
    timeRemaining,
    resetTimer,
    logoutUser,
    showWarning
  };

  return (
    <SessionContext.Provider value={value}>
      {children}
    </SessionContext.Provider>
  );
};

export const useSession = () => {
  const context = useContext(SessionContext);
  if (context === undefined) {
    throw new Error('useSession must be used within a SessionTimeoutProvider');
  }
  return context;
};

interface SessionTimerProps {
  displayMode: 'tooltip' | 'footer' | 'full';
}

export const SessionTimer = ({ displayMode }: SessionTimerProps) => {
  const { timeRemaining, showWarning } = useSession();
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };
  
  if (displayMode === 'tooltip') {
    return <span>Session: {formatTime(timeRemaining)}</span>;
  }
  
  if (displayMode === 'footer') {
    return (
      <span className={showWarning ? 'session-warning px-2 py-1 rounded' : ''}>
        Session expires in: {formatTime(timeRemaining)}
      </span>
    );
  }
  
  // Full display
  return (
    <div className="flex items-center">
      <i className={`ri-timer-line mr-2 ${showWarning ? 'text-accent' : 'text-gray-500'}`}></i>
      <div>
        <p className="text-xs font-medium">Session Timeout</p>
        <p className={`text-sm ${showWarning ? 'text-accent font-bold' : ''}`}>
          {formatTime(timeRemaining)}
        </p>
      </div>
    </div>
  );
};
