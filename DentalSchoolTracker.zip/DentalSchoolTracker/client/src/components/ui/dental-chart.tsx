import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

export type ToothStatus = "healthy" | "treated" | "needs-treatment" | "missing" | "crown" | "implant" | "bridge";

export type ToothSurface = "mesial" | "occlusal" | "distal" | "buccal" | "lingual";

export type ToothTreatment = {
  id: string;
  type: string;
  date: string;
  surface?: ToothSurface[];
  note?: string;
};

export type ToothData = {
  id: number;
  status: ToothStatus;
  notes?: string;
  treatments?: ToothTreatment[];
  surfaces?: Record<ToothSurface, ToothStatus>;
};

export type DentalChartData = {
  upperTeeth: ToothData[];
  lowerTeeth: ToothData[];
  lastUpdated?: string;
};

interface DentalChartProps {
  data: DentalChartData;
  editable?: boolean;
  onToothClick?: (toothId: number, currentStatus: ToothStatus) => void;
  className?: string;
}

const DentalChart = ({
  data,
  editable = false,
  onToothClick,
  className,
}: DentalChartProps) => {
  const [chartData, setChartData] = useState<DentalChartData>(data);

  useEffect(() => {
    setChartData(data);
  }, [data]);

  const handleToothClick = (toothId: number, section: "upper" | "lower", surface?: ToothSurface) => {
    if (!editable) return;
    
    const teethArray = section === "upper" ? "upperTeeth" : "lowerTeeth";
    const toothIndex = chartData[teethArray].findIndex((t) => t.id === toothId);
    
    if (toothIndex === -1) return;
    
    const tooth = chartData[teethArray][toothIndex];
    const currentStatus = tooth.status;
    
    // Update local state
    const newChartData = { ...chartData };
    let newStatus: ToothStatus = "healthy";
    
    // If clicking on a specific surface
    if (surface) {
      // Initialize surfaces object if it doesn't exist
      if (!tooth.surfaces) {
        newChartData[teethArray][toothIndex].surfaces = {
          mesial: "healthy",
          occlusal: "healthy",
          distal: "healthy",
          buccal: "healthy",
          lingual: "healthy"
        } as Record<ToothSurface, ToothStatus>;
      }
      
      // Get current surface status
      const currentSurfaceStatus = tooth.surfaces?.[surface] || "healthy";
      
      // Cycle through statuses for the surface
      let newSurfaceStatus: ToothStatus = "healthy";
      if (currentSurfaceStatus === "healthy") {
        newSurfaceStatus = "needs-treatment";
      } else if (currentSurfaceStatus === "needs-treatment") {
        newSurfaceStatus = "treated";
      } else {
        newSurfaceStatus = "healthy";
      }
      
      // Update surface status
      newChartData[teethArray][toothIndex].surfaces = {
        ...newChartData[teethArray][toothIndex].surfaces,
        [surface]: newSurfaceStatus
      } as Record<ToothSurface, ToothStatus>;
    } else {
      // Clicking on the entire tooth
      if (currentStatus === "healthy") {
        newStatus = "needs-treatment";
      } else if (currentStatus === "needs-treatment") {
        newStatus = "treated";
      } else if (currentStatus === "treated") {
        newStatus = "missing";
      } else if (currentStatus === "missing") {
        newStatus = "crown";
      } else if (currentStatus === "crown") {
        newStatus = "implant";
      } else if (currentStatus === "implant") {
        newStatus = "bridge";
      } else {
        newStatus = "healthy";
      }
      
      newChartData[teethArray][toothIndex].status = newStatus;
      
      // Reset surfaces when changing entire tooth status
      if (newStatus !== "healthy" && newStatus !== "needs-treatment" && newStatus !== "treated") {
        newChartData[teethArray][toothIndex].surfaces = undefined;
      }
    }
    
    setChartData(newChartData);
    
    // Call callback if provided
    if (onToothClick) {
      onToothClick(toothId, currentStatus);
    }
  };

  const renderToothSurfaces = (tooth: ToothData, section: "upper" | "lower", x: number, y: number) => {
    // Create geometry for the 5 surfaces of a tooth 
    // (mesial, occlusal, distal, buccal, lingual)
    const toothWidth = 30;
    const toothHeight = 36;
    
    // Default colors
    const defaultFill = tooth.status === "missing" ? "none" : 
                        tooth.status === "crown" ? "#B0B0B0" : 
                        tooth.status === "implant" ? "#A0A0A0" : 
                        tooth.status === "bridge" ? "#C0C0C0" : 
                        "white";
    
    // Define tooth surfaces with click handlers
    const paths = {
      // Top surface (occlusal)
      occlusal: (
        <rect 
          x={x + 6} 
          y={y + 9} 
          width={18} 
          height={18} 
          fill={tooth.surfaces?.occlusal ? getStatusColor(tooth.surfaces.occlusal) : defaultFill}
          className={editable ? "cursor-pointer" : ""}
          onClick={(e) => {
            e.stopPropagation();
            if (editable) handleToothClick(tooth.id, section, "occlusal");
          }}
        />
      ),
      
      // Left surface (mesial)
      mesial: (
        <path 
          d={`M ${x + 6} ${y + 9} L ${x + 6} ${y + 27} L ${x} ${y + 36} L ${x} ${y} Z`} 
          fill={tooth.surfaces?.mesial ? getStatusColor(tooth.surfaces.mesial) : defaultFill}
          className={editable ? "cursor-pointer" : ""}
          onClick={(e) => {
            e.stopPropagation();
            if (editable) handleToothClick(tooth.id, section, "mesial");
          }}
        />
      ),
      
      // Right surface (distal)
      distal: (
        <path 
          d={`M ${x + 24} ${y + 9} L ${x + 24} ${y + 27} L ${x + 30} ${y + 36} L ${x + 30} ${y} Z`} 
          fill={tooth.surfaces?.distal ? getStatusColor(tooth.surfaces.distal) : defaultFill}
          className={editable ? "cursor-pointer" : ""}
          onClick={(e) => {
            e.stopPropagation();
            if (editable) handleToothClick(tooth.id, section, "distal");
          }}
        />
      ),
      
      // Bottom surface (lingual) - on inner side of mouth
      lingual: section === "upper" 
        ? (
          <path 
            d={`M ${x + 6} ${y + 27} L ${x + 24} ${y + 27} L ${x + 30} ${y + 36} L ${x} ${y + 36} Z`} 
            fill={tooth.surfaces?.lingual ? getStatusColor(tooth.surfaces.lingual) : defaultFill}
            className={editable ? "cursor-pointer" : ""}
            onClick={(e) => {
              e.stopPropagation();
              if (editable) handleToothClick(tooth.id, section, "lingual");
            }}
          />
        )
        : (
          <path 
            d={`M ${x + 6} ${y + 9} L ${x + 24} ${y + 9} L ${x + 30} ${y} L ${x} ${y} Z`} 
            fill={tooth.surfaces?.lingual ? getStatusColor(tooth.surfaces.lingual) : defaultFill}
            className={editable ? "cursor-pointer" : ""}
            onClick={(e) => {
              e.stopPropagation();
              if (editable) handleToothClick(tooth.id, section, "lingual");
            }}
          />
        ),
      
      // Top surface (buccal) - facing cheek
      buccal: section === "upper"
        ? (
          <path 
            d={`M ${x + 6} ${y + 9} L ${x + 24} ${y + 9} L ${x + 30} ${y} L ${x} ${y} Z`} 
            fill={tooth.surfaces?.buccal ? getStatusColor(tooth.surfaces.buccal) : defaultFill}
            className={editable ? "cursor-pointer" : ""}
            onClick={(e) => {
              e.stopPropagation();
              if (editable) handleToothClick(tooth.id, section, "buccal");
            }}
          />
        )
        : (
          <path 
            d={`M ${x + 6} ${y + 27} L ${x + 24} ${y + 27} L ${x + 30} ${y + 36} L ${x} ${y + 36} Z`} 
            fill={tooth.surfaces?.buccal ? getStatusColor(tooth.surfaces.buccal) : defaultFill}
            className={editable ? "cursor-pointer" : ""}
            onClick={(e) => {
              e.stopPropagation();
              if (editable) handleToothClick(tooth.id, section, "buccal");
            }}
          />
        )
    };
    
    // For certain statuses, we need to modify the rendering
    let specialRendering = null;
    
    if (tooth.status === "missing") {
      specialRendering = (
        <g>
          <line x1={x} y1={y} x2={x + 30} y2={y + 36} stroke="#FF6B6B" strokeWidth="2" />
          <line x1={x} y1={y + 36} x2={x + 30} y2={y} stroke="#FF6B6B" strokeWidth="2" />
        </g>
      );
    } else if (tooth.status === "crown") {
      specialRendering = <rect x={x} y={y} width={30} height={36} rx={4} fill="#B0B0B0" stroke="#555" strokeWidth="1" />;
    } else if (tooth.status === "implant") {
      specialRendering = (
        <g>
          <rect x={x} y={y} width={30} height={36} rx={4} fill="#A0A0A0" stroke="#555" strokeWidth="1" />
          <circle cx={x + 15} cy={y + 18} r={6} fill="none" stroke="#555" strokeWidth="1" />
          <line x1={x + 15} y1={y + 6} x2={x + 15} y2={y + 30} stroke="#555" strokeWidth="1" />
        </g>
      );
    } else if (tooth.status === "bridge") {
      specialRendering = (
        <g>
          <rect x={x} y={y} width={30} height={36} rx={4} fill="#C0C0C0" stroke="#555" strokeWidth="1" />
          <line x1={x - 5} y1={y + 18} x2={x + 35} y2={y + 18} stroke="#555" strokeWidth="2" />
        </g>
      );
    }
    
    return (
      <g data-tooth={tooth.id}>
        {specialRendering ? (
          specialRendering
        ) : (
          <>
            {paths.mesial}
            {paths.occlusal}
            {paths.distal}
            {paths.buccal}
            {paths.lingual}
          </>
        )}
        
        {/* Tooth outline */}
        <rect 
          x={x} 
          y={y} 
          width={30} 
          height={36} 
          rx={4}
          fill="none"
          stroke={tooth.status === "missing" ? "#FF6B6B" : "#555"}
          strokeWidth={tooth.status === "needs-treatment" ? 2 : 1}
          strokeDasharray={tooth.status === "needs-treatment" ? "2,1" : "none"}
          className={editable ? "cursor-pointer" : ""}
        />
        
        {/* Tooth number */}
        <text 
          x={x + 15} 
          y={y + 47} 
          textAnchor="middle" 
          fontSize="9" 
          fill={tooth.status === "needs-treatment" ? "#e11d48" : "#555"}
          fontWeight={tooth.status === "needs-treatment" ? "bold" : "normal"}
        >
          {tooth.id}
        </text>
        
        {/* Treatment indicators */}
        {tooth.treatments && tooth.treatments.length > 0 && (
          <circle cx={x + 25} cy={y + 5} r={4} fill="#00A896" />
        )}
      </g>
    );
  };
  
  const getStatusColor = (status: ToothStatus) => {
    switch (status) {
      case "healthy": return "white";
      case "treated": return "#00A896"; // teal
      case "needs-treatment": return "#FF6B6B"; // coral
      case "missing": return "none";
      case "crown": return "#B0B0B0"; // light gray
      case "implant": return "#A0A0A0"; // medium gray
      case "bridge": return "#C0C0C0"; // dark gray
      default: return "white";
    }
  };
  
  return (
    <div className={cn("dental-chart bg-gray-50 p-4 rounded-md border border-gray-200", className)}>
      <div className="flex justify-center">
        <svg width="600" height="300" viewBox="0 0 600 300" className="dental-chart">
          {/* Chart title and legend */}
          <text x="300" y="20" textAnchor="middle" className="text-base font-medium">Dental Chart</text>
          
          {/* Upper Teeth */}
          <g transform="translate(50, 40)">
            <text x="250" y="15" textAnchor="middle" className="text-xs font-medium">Upper Teeth (Adult)</text>
            
            {/* Teeth numbers 1-16 */}
            <g>
              {chartData.upperTeeth.map((tooth) => (
                <g 
                  key={`upper-${tooth.id}`} 
                  onClick={() => handleToothClick(tooth.id, "upper")}
                  className={editable ? "hover:opacity-90" : ""}
                >
                  {renderToothSurfaces(
                    tooth, 
                    "upper", 
                    10 + (tooth.id - 1) * 32, 
                    30
                  )}
                </g>
              ))}
            </g>
          </g>
          
          {/* Lower Teeth */}
          <g transform="translate(50, 160)">
            <text x="250" y="15" textAnchor="middle" className="text-xs font-medium">Lower Teeth (Adult)</text>
            
            {/* Teeth numbers 17-32 */}
            <g>
              {chartData.lowerTeeth.map((tooth) => (
                <g 
                  key={`lower-${tooth.id}`} 
                  onClick={() => handleToothClick(tooth.id, "lower")}
                  className={editable ? "hover:opacity-90" : ""}
                >
                  {renderToothSurfaces(
                    tooth, 
                    "lower", 
                    10 + (tooth.id - 17) * 32, 
                    30
                  )}
                </g>
              ))}
            </g>
          </g>
        </svg>
      </div>
      
      <div className="flex flex-wrap justify-center mt-4 gap-2 text-xs">
        <div className="flex items-center px-2 py-1 bg-white rounded border">
          <span className="w-3 h-3 bg-white border border-gray-300 rounded-sm mr-1"></span>
          <span>Healthy</span>
        </div>
        <div className="flex items-center px-2 py-1 bg-white rounded border">
          <span className="w-3 h-3 bg-[#00A896] rounded-sm mr-1"></span>
          <span>Treated</span>
        </div>
        <div className="flex items-center px-2 py-1 bg-white rounded border">
          <span className="w-3 h-3 bg-[#FF6B6B] rounded-sm mr-1"></span>
          <span>Needs Treatment</span>
        </div>
        <div className="flex items-center px-2 py-1 bg-white rounded border">
          <span className="w-3 h-3 border border-[#FF6B6B] rounded-sm mr-1 relative">
            <span className="absolute inset-0 flex items-center justify-center text-[8px] text-[#FF6B6B]">X</span>
          </span>
          <span>Missing</span>
        </div>
        <div className="flex items-center px-2 py-1 bg-white rounded border">
          <span className="w-3 h-3 bg-[#B0B0B0] rounded-sm mr-1"></span>
          <span>Crown</span>
        </div>
        <div className="flex items-center px-2 py-1 bg-white rounded border">
          <span className="w-3 h-3 bg-[#A0A0A0] rounded-sm mr-1 flex items-center justify-center">
            <span className="w-1.5 h-1.5 rounded-full border border-gray-500"></span>
          </span>
          <span>Implant</span>
        </div>
        <div className="flex items-center px-2 py-1 bg-white rounded border">
          <span className="w-3 h-3 bg-[#C0C0C0] rounded-sm mr-1 flex items-center justify-center">
            <span className="w-3 h-px bg-gray-500"></span>
          </span>
          <span>Bridge</span>
        </div>
      </div>
    </div>
  );
};

export default DentalChart;
