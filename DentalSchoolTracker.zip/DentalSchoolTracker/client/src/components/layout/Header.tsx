import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SessionTimer } from "@/components/ui/session-timer";

const Header = () => {
  const [searchQuery, setSearchQuery] = useState("");
  
  return (
    <header className="bg-white border-b border-gray-200 shadow-sm">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <button className="p-2 rounded-md hover:bg-gray-100 mr-4 lg:hidden">
            <i className="ri-menu-line text-gray-500"></i>
          </button>
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <Input
              type="search"
              placeholder="Search patients, appointments..."
              className="pl-10 pr-4 py-2 w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="p-2 rounded-full hover:bg-gray-100 relative">
            <i className="ri-notification-3-line text-gray-500"></i>
            <span className="absolute top-0 right-0 h-4 w-4 bg-accent rounded-full border-2 border-white"></span>
          </button>
          
          <div className="tooltip">
            <button className="p-2 rounded-full hover:bg-gray-100">
              <i className="ri-lock-line text-gray-500"></i>
            </button>
            <span className="tooltiptext">HIPAA Compliant</span>
          </div>
          
          <div className="tooltip">
            <button className="p-2 rounded-full hover:bg-gray-100">
              <i className="ri-timer-line text-gray-500"></i>
            </button>
            <span className="tooltiptext">
              <SessionTimer displayMode="tooltip" />
            </span>
          </div>
          
          <Link href="/patients">
            <Button className="bg-primary text-white hover:bg-blue-700 flex items-center">
              <i className="ri-add-line mr-1"></i>
              New Patient
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="px-4 py-2 bg-gray-50 border-t border-gray-200 flex items-center text-sm">
        <Link href="/dashboard">
          <a className="text-primary">Home</a>
        </Link>
        <i className="ri-arrow-right-s-line mx-2 text-gray-400"></i>
        <span className="text-gray-500">Dashboard</span>
        
        <div className="ml-auto flex items-center space-x-2">
          <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full flex items-center">
            <i className="ri-check-line mr-1"></i> System Online
          </span>
          <span className="text-xs text-gray-500">
            Last sync: {new Date().toLocaleString('en-US', {
              hour: 'numeric',
              minute: 'numeric',
              hour12: true
            })}
          </span>
        </div>
      </div>
    </header>
  );
};

export default Header;
