import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

type NavItemProps = {
  href: string;
  icon: string;
  label: string;
  badge?: string;
};

const NavItem = ({ href, icon, label, badge }: NavItemProps) => {
  const [location] = useLocation();
  const isActive = location === href;

  return (
    <li>
      <Link href={href}>
        <a className={cn(
          "flex items-center p-3 rounded-md",
          isActive 
            ? "bg-blue-50 text-primary font-medium" 
            : "text-text-dark hover:bg-gray-100"
        )}>
          <i className={`ri-${icon}-line mr-3`}></i>
          <span>{label}</span>
          {badge && (
            <span className="ml-auto bg-accent text-white text-xs px-2 py-1 rounded-full">
              {badge}
            </span>
          )}
        </a>
      </Link>
    </li>
  );
};

const Sidebar = () => {
  const { user, logout } = useAuth();
  
  const initials = user?.firstName && user?.lastName 
    ? `${user.firstName[0]}${user.lastName[0]}` 
    : "U";

  return (
    <div className="w-64 bg-white h-full flex flex-col border-r border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center">
          <i className="ri-heart-pulse-line text-primary text-2xl mr-2"></i>
          <h1 className="text-xl font-semibold text-primary">DentalEdu</h1>
        </div>
        <p className="text-xs text-gray-500 mt-1">Dental Practice Management</p>
      </div>
      
      <nav className="flex-1 overflow-y-auto p-4">
        <ul className="space-y-1">
          <NavItem href="/dashboard" icon="dashboard" label="Dashboard" />
          <NavItem href="/appointments" icon="calendar" label="Appointments" />
          <NavItem href="/patients" icon="user" label="Patients" />
          <NavItem href="/dental-charts" icon="teeth" label="Dental Charts" />
          <NavItem href="/clinical-notes" icon="file-text" label="Clinical Notes" />
          <NavItem href="/treatment-plans" icon="clipboard-list" label="Treatment Plans" badge="New" />
          <NavItem href="/ai-assistant" icon="robot" label="AI Assistant" />
        </ul>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Admin</h3>
          <ul className="mt-3 space-y-1">
            <NavItem href="/settings" icon="settings" label="Settings" />
            <NavItem href="/audit-logs" icon="shield-check" label="Audit Logs" />
            <NavItem href="/help" icon="question" label="Help & Resources" />
          </ul>
        </div>
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center">
            <span className="font-semibold">{initials}</span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium">
              {user?.firstName} {user?.lastName}
            </p>
            <p className="text-xs text-gray-500">
              {user?.role === "dentist" ? "Dental Student" : user?.role}
            </p>
          </div>
          <button 
            className="ml-auto text-gray-400 hover:text-gray-600"
            onClick={logout}
          >
            <i className="ri-logout-box-r-line"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
