import { useEffect, ReactNode } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import Footer from "./Footer";
import { useAuth } from "@/lib/auth";
import { useSession } from "@/components/ui/session-timer";

interface MainLayoutProps {
  children: ReactNode;
}

const MainLayout = ({ children }: MainLayoutProps) => {
  const { user } = useAuth();
  const { resetTimer, logoutUser } = useSession();
  
  // Handle user activity to reset session timer
  useEffect(() => {
    const resetOnActivity = () => {
      resetTimer();
    };
    
    window.addEventListener("mousemove", resetOnActivity);
    window.addEventListener("keypress", resetOnActivity);
    window.addEventListener("click", resetOnActivity);
    
    return () => {
      window.removeEventListener("mousemove", resetOnActivity);
      window.removeEventListener("keypress", resetOnActivity);
      window.removeEventListener("click", resetOnActivity);
    };
  }, [resetTimer]);
  
  // Handle HIPAA security audit logging
  useEffect(() => {
    // Log page access for HIPAA audit
    if (user?.id) {
      const logAudit = async () => {
        try {
          await fetch('/api/audit-logs', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId: user.id,
              action: 'view',
              resourceType: 'page',
              resourceId: window.location.pathname,
              details: `User viewed page: ${window.location.pathname}`,
              ipAddress: '0.0.0.0', // This would be captured on server side
              userAgent: navigator.userAgent
            })
          });
        } catch (error) {
          console.error('Failed to log audit', error);
        }
      };
      
      logAudit();
    }
  }, [user, window.location.pathname]);
  
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto bg-background p-4">
          {children}
        </main>
        
        <Footer />
      </div>
    </div>
  );
};

export default MainLayout;
