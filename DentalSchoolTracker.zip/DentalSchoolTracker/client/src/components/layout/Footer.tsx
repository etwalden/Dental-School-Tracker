import { Link } from "wouter";
import { SessionTimer } from "@/components/ui/session-timer";

const Footer = () => {
  return (
    <footer className="bg-white border-t border-gray-200 p-4">
      <div className="flex items-center justify-between">
        <div className="text-xs text-gray-500">
          <p>DentalEdu Practice Management System</p>
          <p>
            HIPAA Compliant | Data Encrypted | <Link href="/privacy-policy"><a className="hover:underline">Privacy Policy</a></Link>
          </p>
        </div>
        <div className="flex items-center text-xs text-gray-500">
          <div className="flex items-center mr-4">
            <i className="ri-shield-check-line text-green-500 mr-1"></i>
            <span>Protected Health Information</span>
          </div>
          <div className="flex items-center">
            <i className="ri-time-line mr-1"></i>
            <SessionTimer displayMode="footer" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
