import { apiRequest } from "./queryClient";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user

/**
 * Generate AI suggestions for treatment based on dental chart data
 * @param patientId The ID of the patient
 * @param chartData The dental chart data
 */
export async function generateTreatmentSuggestions(patientId: number, chartData: any) {
  try {
    const response = await apiRequest("POST", "/api/ai/generate-treatment-suggestions", {
      patientId,
      chartData,
    });
    
    return await response.json();
  } catch (error) {
    console.error("Failed to generate treatment suggestions:", error);
    throw error;
  }
}

/**
 * Generate a clinical note based on patient data and procedure
 * @param patientId The ID of the patient
 * @param procedure The dental procedure performed
 */
export async function generateClinicalNote(patientId: number, procedure: string) {
  try {
    const response = await apiRequest("POST", "/api/ai/generate-clinical-note", {
      patientId,
      procedure,
    });
    
    return await response.json();
  } catch (error) {
    console.error("Failed to generate clinical note:", error);
    throw error;
  }
}

/**
 * Send a message to the AI chatbot and get a response
 * @param message The user's message
 * @param userId The ID of the user sending the message
 */
export async function chatWithAI(message: string, userId: number) {
  try {
    const response = await apiRequest("POST", "/api/ai/chat", {
      message,
      userId,
    });
    
    return await response.json();
  } catch (error) {
    console.error("Failed to chat with AI:", error);
    throw error;
  }
}

/**
 * Analyze symptoms and provide preliminary diagnosis suggestions
 * @param symptoms Description of the patient's symptoms
 * @param patientHistory Brief patient history
 */
export async function analyzeSymptoms(symptoms: string, patientHistory: string) {
  try {
    const response = await apiRequest("POST", "/api/ai/analyze-symptoms", {
      symptoms,
      patientHistory,
    });
    
    return await response.json();
  } catch (error) {
    console.error("Failed to analyze symptoms:", error);
    throw error;
  }
}

export const openai = {
  generateTreatmentSuggestions,
  generateClinicalNote,
  chatWithAI,
  analyzeSymptoms,
};
