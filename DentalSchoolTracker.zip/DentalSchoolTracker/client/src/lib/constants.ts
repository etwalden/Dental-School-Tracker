// Appointment related constants
export const APPOINTMENT_TYPES = [
  "check-up",
  "cleaning",
  "root canal",
  "consultation",
  "filling",
  "crown",
  "extraction",
  "other"
] as const;

export const APPOINTMENT_DURATIONS = [
  { value: "15", label: "15 minutes" },
  { value: "30", label: "30 minutes" },
  { value: "45", label: "45 minutes" },
  { value: "60", label: "1 hour" },
  { value: "90", label: "1.5 hours" },
  { value: "120", label: "2 hours" },
] as const;

export const APPOINTMENT_STATUS = [
  "scheduled",
  "confirmed", 
  "completed", 
  "cancelled", 
  "no-show"
] as const;

// Dental chart constants
export const TOOTH_STATUS = {
  HEALTHY: "healthy",
  TREATED: "treated",
  NEEDS_TREATMENT: "needs-treatment"
} as const;

export const TREATMENT_TYPES = [
  "filling", 
  "crown", 
  "root canal", 
  "extraction", 
  "cleaning", 
  "bridge",
  "implant",
  "veneer",
  "whitening",
  "other"
] as const;

export const TREATMENT_STATUS = [
  "planned",
  "in-progress",
  "completed"
] as const;

// User related constants
export const USER_ROLES = [
  "dentist",
  "assistant",
  "admin"
] as const;

// HIPAA compliance constants
export const SESSION_TIMEOUT_MINUTES = 15;
export const SESSION_WARNING_MINUTES = 2;

// AI suggestion constants 
export const AI_SUGGESTION_TYPES = [
  "treatment",
  "diagnosis",
  "preventive",
  "patient-education"
] as const;

export const AI_SUGGESTION_STATUS = [
  "pending",
  "approved",
  "dismissed"
] as const;

export const AI_SUGGESTION_BASED_ON = [
  "dental chart",
  "clinical history",
  "x-ray analysis",
  "symptoms"
] as const;

// Audit logging constants
export const AUDIT_ACTION_TYPES = [
  "view",
  "create",
  "update",
  "delete",
  "login",
  "logout",
  "export"
] as const;

export const AUDIT_RESOURCE_TYPES = [
  "patient",
  "appointment",
  "dental-chart",
  "clinical-note",
  "treatment",
  "user",
  "session",
  "page"
] as const;
