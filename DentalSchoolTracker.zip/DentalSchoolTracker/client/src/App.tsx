import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect, useState } from "react";

// Pages
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Appointments from "@/pages/appointments";
import Patients from "@/pages/patients/index";
import PatientDetail from "@/pages/patients/[id]";
import DentalCharts from "@/pages/dental-charts";
import ClinicalNotes from "@/pages/clinical-notes";
import TreatmentPlans from "@/pages/treatment-plans";
import Settings from "@/pages/settings";
import AuditLogs from "@/pages/audit-logs";
import NotFound from "@/pages/not-found";

// Components
import MainLayout from "@/components/layout/MainLayout";
import AIAssistant from "@/components/ai/AIAssistant";
import { SessionTimeoutProvider } from "@/components/ui/session-timer";

// Auth context
import { useAuth, AuthProvider } from "./lib/auth";

// Protected route component
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { isAuthenticated, loading } = useAuth();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return <>{children}</>;
}

function Router() {
  const [location] = useLocation();
  const isLoginPage = location === "/login";

  return (
    <>
      <Switch>
        <Route path="/login" component={Login} />
        
        <Route path="/">
          <ProtectedRoute>
            <MainLayout>
              <Dashboard />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route path="/dashboard">
          <ProtectedRoute>
            <MainLayout>
              <Dashboard />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route path="/appointments">
          <ProtectedRoute>
            <MainLayout>
              <Appointments />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route path="/patients">
          <ProtectedRoute>
            <MainLayout>
              <Patients />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route path="/patients/:id">
          {(params) => (
            <ProtectedRoute>
              <MainLayout>
                <PatientDetail id={params.id} />
              </MainLayout>
            </ProtectedRoute>
          )}
        </Route>
        
        <Route path="/dental-charts">
          <ProtectedRoute>
            <MainLayout>
              <DentalCharts />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route path="/clinical-notes">
          <ProtectedRoute>
            <MainLayout>
              <ClinicalNotes />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route path="/treatment-plans">
          <ProtectedRoute>
            <MainLayout>
              <TreatmentPlans />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route path="/settings">
          <ProtectedRoute>
            <MainLayout>
              <Settings />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route path="/audit-logs">
          <ProtectedRoute>
            <MainLayout>
              <AuditLogs />
            </MainLayout>
          </ProtectedRoute>
        </Route>
        
        <Route component={NotFound} />
      </Switch>
      
      {!isLoginPage && (
        <ProtectedRoute>
          <AIAssistant />
        </ProtectedRoute>
      )}
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <SessionTimeoutProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </SessionTimeoutProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
