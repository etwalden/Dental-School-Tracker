import { 
  users, User, InsertUser,
  patients, Patient, InsertPatient,
  appointments, Appointment, InsertAppointment,
  dentalCharts, DentalChart, InsertDentalChart,
  clinicalNotes, ClinicalNote, InsertClinicalNote,
  treatments, Treatment, InsertTreatment,
  adaProcedureCodes, AdaProcedureCode, InsertAdaProcedureCode,
  aiSuggestions, AiSuggestion, InsertAiSuggestion,
  auditLogs, AuditLog, InsertAuditLog
} from "@shared/schema";
import bcrypt from "bcrypt";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User>;
  updateUserLastLogin(id: number): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  // Patients
  getPatient(id: number): Promise<Patient | undefined>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  updatePatient(id: number, patientData: Partial<Patient>): Promise<Patient>;
  getAllPatients(): Promise<Patient[]>;
  getNewPatientsCount(fromDate: Date): Promise<number>;
  
  // Appointments
  getAppointments(fromDate?: Date, toDate?: Date): Promise<Appointment[]>;
  getPatientAppointments(patientId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment>;
  getPendingRecordsCount(): Promise<number>;
  
  // Dental Charts
  getDentalChart(id: number): Promise<DentalChart | undefined>;
  getPatientDentalChart(patientId: number): Promise<DentalChart | undefined>;
  createDentalChart(chart: InsertDentalChart): Promise<DentalChart>;
  updateDentalChart(id: number, chartData: Partial<DentalChart>): Promise<DentalChart>;
  getRecentDentalCharts(limit: number): Promise<DentalChart[]>;
  
  // Clinical Notes
  getClinicalNote(id: number): Promise<ClinicalNote | undefined>;
  getPatientClinicalNotes(patientId: number): Promise<ClinicalNote[]>;
  createClinicalNote(note: InsertClinicalNote): Promise<ClinicalNote>;
  getAllClinicalNotes(): Promise<ClinicalNote[]>;
  
  // Treatments
  getTreatment(id: number): Promise<Treatment | undefined>;
  getPatientTreatments(patientId: number): Promise<Treatment[]>;
  createTreatment(treatment: InsertTreatment): Promise<Treatment>;
  updateTreatment(id: number, treatmentData: Partial<Treatment>): Promise<Treatment>;
  
  // ADA Procedure Codes
  getAdaProcedureCodes(): Promise<AdaProcedureCode[]>;
  getAdaProcedureCode(id: number): Promise<AdaProcedureCode | undefined>;
  getAdaProcedureCodeByCode(code: string): Promise<AdaProcedureCode | undefined>;
  createAdaProcedureCode(code: InsertAdaProcedureCode): Promise<AdaProcedureCode>;
  
  // AI Suggestions
  getAiSuggestion(id: number): Promise<AiSuggestion | undefined>;
  getPatientAiSuggestions(patientId: number): Promise<AiSuggestion[]>;
  createAiSuggestion(suggestion: InsertAiSuggestion): Promise<AiSuggestion>;
  updateAiSuggestion(id: number, suggestionData: Partial<AiSuggestion>): Promise<AiSuggestion>;
  getAiSuggestions(): Promise<AiSuggestion[]>;
  getPendingAiSuggestionsCount(): Promise<number>;
  getRecentAiSuggestions(limit: number): Promise<AiSuggestion[]>;
  
  // Audit Logs
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(action?: string, resourceType?: string, dateRange?: string): Promise<AuditLog[]>;
}

export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private patientsMap: Map<number, Patient>;
  private appointmentsMap: Map<number, Appointment>;
  private dentalChartsMap: Map<number, DentalChart>;
  private clinicalNotesMap: Map<number, ClinicalNote>;
  private treatmentsMap: Map<number, Treatment>;
  private adaProcedureCodesMap: Map<number, AdaProcedureCode>;
  private aiSuggestionsMap: Map<number, AiSuggestion>;
  private auditLogsMap: Map<number, AuditLog>;
  
  // IDs for auto-increment
  private userId: number;
  private patientId: number;
  private appointmentId: number;
  private dentalChartId: number;
  private clinicalNoteId: number;
  private treatmentId: number;
  private adaProcedureCodeId: number;
  private aiSuggestionId: number;
  private auditLogId: number;

  constructor() {
    // Initialize maps
    this.usersMap = new Map();
    this.patientsMap = new Map();
    this.appointmentsMap = new Map();
    this.dentalChartsMap = new Map();
    this.clinicalNotesMap = new Map();
    this.treatmentsMap = new Map();
    this.adaProcedureCodesMap = new Map();
    this.aiSuggestionsMap = new Map();
    this.auditLogsMap = new Map();
    
    // Initialize IDs
    this.userId = 1;
    this.patientId = 1;
    this.appointmentId = 1;
    this.dentalChartId = 1;
    this.clinicalNoteId = 1;
    this.treatmentId = 1;
    this.adaProcedureCodeId = 1;
    this.aiSuggestionId = 1;
    this.auditLogId = 1;
    
    // Create initial admin user
    this.seedDatabase();
  }

  // ADA Procedure Codes
  async getAdaProcedureCodes(): Promise<AdaProcedureCode[]> {
    return Array.from(this.adaProcedureCodesMap.values());
  }
  
  async getAdaProcedureCode(id: number): Promise<AdaProcedureCode | undefined> {
    return this.adaProcedureCodesMap.get(id);
  }
  
  async getAdaProcedureCodeByCode(code: string): Promise<AdaProcedureCode | undefined> {
    return Array.from(this.adaProcedureCodesMap.values()).find(
      (adaCode) => adaCode.code === code
    );
  }
  
  async createAdaProcedureCode(codeData: InsertAdaProcedureCode): Promise<AdaProcedureCode> {
    const id = this.adaProcedureCodeId++;
    
    const adaCode: AdaProcedureCode = {
      id,
      code: codeData.code,
      description: codeData.description,
      category: codeData.category,
      fee: codeData.fee,
      createdAt: new Date()
    };
    
    this.adaProcedureCodesMap.set(id, adaCode);
    return adaCode;
  }
  
  private async seedDatabase() {
    // Create admin user
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash("password", salt);
    
    const adminUser: User = {
      id: this.userId++,
      username: "admin",
      password: hashedPassword,
      firstName: "Admin",
      lastName: "User",
      email: "admin@dentaledu.com",
      role: "admin",
      profilePicture: "",
      createdAt: new Date(),
      lastLogin: null
    };
    this.usersMap.set(adminUser.id, adminUser);
    
    // Create dentist user
    const dentistUser: User = {
      id: this.userId++,
      username: "dentist",
      password: hashedPassword,
      firstName: "Sarah",
      lastName: "Wilson",
      email: "sarah@dentaledu.com",
      role: "dentist",
      profilePicture: "",
      createdAt: new Date(),
      lastLogin: null
    };
    this.usersMap.set(dentistUser.id, dentistUser);
    
    // Create assistant user
    const assistantUser: User = {
      id: this.userId++,
      username: "assistant",
      password: hashedPassword,
      firstName: "Michael",
      lastName: "Johnson",
      email: "michael@dentaledu.com",
      role: "assistant",
      profilePicture: "",
      createdAt: new Date(),
      lastLogin: null
    };
    this.usersMap.set(assistantUser.id, assistantUser);
    
    // Create sample patients
    const patientNames = [
      { first: "John", last: "Doe" },
      { first: "Emily", last: "Johnson" },
      { first: "Michael", last: "Smith" },
      { first: "David", last: "Williams" },
      { first: "Jessica", last: "Brown" }
    ];
    
    for (const name of patientNames) {
      const dob = new Date();
      dob.setFullYear(dob.getFullYear() - 20 - Math.floor(Math.random() * 40));
      
      const patient: Patient = {
        id: this.patientId++,
        firstName: name.first,
        lastName: name.last,
        dateOfBirth: dob,
        email: `${name.first.toLowerCase()}@example.com`,
        phone: `(${Math.floor(Math.random() * 900) + 100}) ${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 9000) + 1000}`,
        address: `${Math.floor(Math.random() * 999) + 1} Main St`,
        city: "Anytown",
        state: "CA",
        zipCode: `${Math.floor(Math.random() * 90000) + 10000}`,
        insurance: "HealthPlus Insurance",
        insuranceId: `INS-${Math.floor(Math.random() * 1000000)}`,
        medicalHistory: "No significant medical history",
        allergies: "No known allergies",
        createdAt: new Date(),
        updatedAt: new Date()
      };
      this.patientsMap.set(patient.id, patient);
      
      // Create appointments for each patient
      const appointmentTypes = ["check-up", "cleaning", "root canal", "consultation"];
      const today = new Date();
      
      for (let i = 0; i < 2; i++) {
        const appointmentDate = new Date(today);
        appointmentDate.setHours(9 + Math.floor(Math.random() * 8), Math.floor(Math.random() * 4) * 15, 0, 0);
        
        if (i === 1) {
          appointmentDate.setDate(appointmentDate.getDate() + Math.floor(Math.random() * 30));
        }
        
        const appointment: Appointment = {
          id: this.appointmentId++,
          patientId: patient.id,
          doctorId: dentistUser.id,
          date: appointmentDate,
          duration: (Math.floor(Math.random() * 3) + 1) * 30,
          type: appointmentTypes[Math.floor(Math.random() * appointmentTypes.length)],
          notes: i === 0 ? "Initial consultation" : "",
          status: i === 0 ? "completed" : "scheduled",
          createdAt: new Date(),
          updatedAt: new Date()
        };
        this.appointmentsMap.set(appointment.id, appointment);
      }
      
      // Create dental chart for each patient
      const dentalChart: DentalChart = {
        id: this.dentalChartId++,
        patientId: patient.id,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastUpdatedBy: dentistUser.id,
        data: this.generateSampleDentalChartData()
      };
      this.dentalChartsMap.set(dentalChart.id, dentalChart);
      
      // Create clinical notes for each patient
      const clinicalNote: ClinicalNote = {
        id: this.clinicalNoteId++,
        patientId: patient.id,
        authorId: dentistUser.id,
        appointmentId: null,
        title: "Initial Examination",
        content: "Patient presented for routine check-up. Oral examination shows good overall dental health with proper oral hygiene. No major issues detected. Recommended regular cleanings every 6 months.",
        isAiGenerated: false,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      this.clinicalNotesMap.set(clinicalNote.id, clinicalNote);
      
      // Create AI generated clinical note
      const aiClinicalNote: ClinicalNote = {
        id: this.clinicalNoteId++,
        patientId: patient.id,
        authorId: dentistUser.id,
        appointmentId: null,
        title: "Follow-up Assessment",
        content: "Patient returned for follow-up after cleaning. Gingival tissues appear healthy with reduced inflammation. Plaque control has improved since last visit. Continuing with current oral hygiene regimen is recommended.",
        isAiGenerated: true,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      this.clinicalNotesMap.set(aiClinicalNote.id, aiClinicalNote);
      
      // Create treatments for each patient
      const treatmentTypes = ["filling", "crown", "cleaning", "extraction"];
      const treatment: Treatment = {
        id: this.treatmentId++,
        patientId: patient.id,
        doctorId: dentistUser.id,
        appointmentId: null,
        type: treatmentTypes[Math.floor(Math.random() * treatmentTypes.length)],
        description: "Standard procedure",
        toothNumber: Math.floor(Math.random() * 32) + 1,
        status: Math.random() > 0.5 ? "completed" : "planned",
        cost: `$${Math.floor(Math.random() * 1000) + 100}`,
        createdAt: new Date(),
        completedAt: Math.random() > 0.5 ? new Date() : null
      };
      this.treatmentsMap.set(treatment.id, treatment);
      
      // Create AI suggestions for each patient
      const aiSuggestion: AiSuggestion = {
        id: this.aiSuggestionId++,
        patientId: patient.id,
        suggestedBy: "gpt-4o",
        content: "Consider preventive sealants for teeth 18, 19, 30, and 31 based on deep occlusal grooves observed.",
        basedOn: "dental chart",
        status: "pending",
        createdAt: new Date(),
        reviewedAt: null,
        reviewedBy: null
      };
      this.aiSuggestionsMap.set(aiSuggestion.id, aiSuggestion);
    }
  }

  private generateSampleDentalChartData() {
    const generateRandomTeeth = () => {
      return Array.from({ length: 16 }, (_, i) => {
        const statuses = ["healthy", "treated", "needs-treatment"] as const;
        const randomStatus = Math.random();
        let status: "healthy" | "treated" | "needs-treatment";
        
        if (randomStatus < 0.7) {
          status = "healthy";
        } else if (randomStatus < 0.85) {
          status = "treated";
        } else {
          status = "needs-treatment";
        }
        
        return {
          id: i + 1,
          status,
          notes: "",
          treatments: []
        };
      });
    };
    
    return {
      upperTeeth: generateRandomTeeth(),
      lowerTeeth: Array.from({ length: 16 }, (_, i) => ({
        id: i + 17,
        status: "healthy" as "healthy" | "treated" | "needs-treatment",
        notes: "",
        treatments: []
      }))
    };
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersMap.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    
    const user: User = {
      ...userData,
      id,
      createdAt: now,
      lastLogin: null
    };
    
    this.usersMap.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    const updatedUser = {
      ...user,
      ...userData,
    };
    
    this.usersMap.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserLastLogin(id: number): Promise<User> {
    const user = await this.getUser(id);
    
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    const updatedUser = {
      ...user,
      lastLogin: new Date()
    };
    
    this.usersMap.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.usersMap.values());
  }

  // Patient methods
  async getPatient(id: number): Promise<Patient | undefined> {
    return this.patientsMap.get(id);
  }

  async createPatient(patientData: InsertPatient): Promise<Patient> {
    const id = this.patientId++;
    const now = new Date();
    
    const patient: Patient = {
      ...patientData,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.patientsMap.set(id, patient);
    return patient;
  }

  async updatePatient(id: number, patientData: Partial<Patient>): Promise<Patient> {
    const patient = await this.getPatient(id);
    
    if (!patient) {
      throw new Error(`Patient with ID ${id} not found`);
    }
    
    const updatedPatient = {
      ...patient,
      ...patientData,
      updatedAt: new Date()
    };
    
    this.patientsMap.set(id, updatedPatient);
    return updatedPatient;
  }

  async getAllPatients(): Promise<Patient[]> {
    return Array.from(this.patientsMap.values());
  }

  async getNewPatientsCount(fromDate: Date): Promise<number> {
    return Array.from(this.patientsMap.values()).filter(
      (patient) => new Date(patient.createdAt) >= fromDate
    ).length;
  }

  // Appointment methods
  async getAppointments(fromDate?: Date, toDate?: Date): Promise<Appointment[]> {
    let appointments = Array.from(this.appointmentsMap.values());
    
    if (fromDate) {
      appointments = appointments.filter(
        (appointment) => new Date(appointment.date) >= fromDate
      );
    }
    
    if (toDate) {
      appointments = appointments.filter(
        (appointment) => new Date(appointment.date) <= toDate
      );
    }
    
    // Sort by date
    return appointments.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }

  async getPatientAppointments(patientId: number): Promise<Appointment[]> {
    return Array.from(this.appointmentsMap.values())
      .filter((appointment) => appointment.patientId === patientId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async createAppointment(appointmentData: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentId++;
    const now = new Date();
    
    const appointment: Appointment = {
      ...appointmentData,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.appointmentsMap.set(id, appointment);
    return appointment;
  }

  async updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment> {
    const appointment = this.appointmentsMap.get(id);
    
    if (!appointment) {
      throw new Error(`Appointment with ID ${id} not found`);
    }
    
    const updatedAppointment = {
      ...appointment,
      ...appointmentData,
      updatedAt: new Date()
    };
    
    this.appointmentsMap.set(id, updatedAppointment);
    return updatedAppointment;
  }

  async getPendingRecordsCount(): Promise<number> {
    // Count appointments that are scheduled but not completed
    return Array.from(this.appointmentsMap.values()).filter(
      (appointment) => appointment.status === "scheduled"
    ).length;
  }

  // Dental Chart methods
  async getDentalChart(id: number): Promise<DentalChart | undefined> {
    return this.dentalChartsMap.get(id);
  }

  async getPatientDentalChart(patientId: number): Promise<DentalChart | undefined> {
    return Array.from(this.dentalChartsMap.values()).find(
      (chart) => chart.patientId === patientId
    );
  }

  async createDentalChart(chartData: InsertDentalChart): Promise<DentalChart> {
    const id = this.dentalChartId++;
    const now = new Date();
    
    const chart: DentalChart = {
      ...chartData,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.dentalChartsMap.set(id, chart);
    return chart;
  }

  async updateDentalChart(id: number, chartData: Partial<DentalChart>): Promise<DentalChart> {
    const chart = this.dentalChartsMap.get(id);
    
    if (!chart) {
      throw new Error(`Dental chart with ID ${id} not found`);
    }
    
    const updatedChart = {
      ...chart,
      ...chartData,
      updatedAt: new Date()
    };
    
    this.dentalChartsMap.set(id, updatedChart);
    return updatedChart;
  }

  async getRecentDentalCharts(limit: number): Promise<DentalChart[]> {
    return Array.from(this.dentalChartsMap.values())
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, limit);
  }

  // Clinical Notes methods
  async getClinicalNote(id: number): Promise<ClinicalNote | undefined> {
    return this.clinicalNotesMap.get(id);
  }

  async getPatientClinicalNotes(patientId: number): Promise<ClinicalNote[]> {
    return Array.from(this.clinicalNotesMap.values())
      .filter((note) => note.patientId === patientId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createClinicalNote(noteData: InsertClinicalNote): Promise<ClinicalNote> {
    const id = this.clinicalNoteId++;
    const now = new Date();
    
    const note: ClinicalNote = {
      ...noteData,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.clinicalNotesMap.set(id, note);
    return note;
  }

  async getAllClinicalNotes(): Promise<ClinicalNote[]> {
    return Array.from(this.clinicalNotesMap.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // Treatment methods
  async getTreatment(id: number): Promise<Treatment | undefined> {
    return this.treatmentsMap.get(id);
  }

  async getPatientTreatments(patientId: number): Promise<Treatment[]> {
    return Array.from(this.treatmentsMap.values())
      .filter((treatment) => treatment.patientId === patientId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createTreatment(treatmentData: InsertTreatment): Promise<Treatment> {
    const id = this.treatmentId++;
    const now = new Date();
    
    const treatment: Treatment = {
      ...treatmentData,
      id,
      createdAt: now,
      completedAt: null
    };
    
    this.treatmentsMap.set(id, treatment);
    return treatment;
  }

  async updateTreatment(id: number, treatmentData: Partial<Treatment>): Promise<Treatment> {
    const treatment = this.treatmentsMap.get(id);
    
    if (!treatment) {
      throw new Error(`Treatment with ID ${id} not found`);
    }
    
    const updatedTreatment = {
      ...treatment,
      ...treatmentData
    };
    
    // If status changed to completed, set completedAt
    if (treatmentData.status === "completed" && treatment.status !== "completed") {
      updatedTreatment.completedAt = new Date();
    }
    
    this.treatmentsMap.set(id, updatedTreatment);
    return updatedTreatment;
  }

  // AI Suggestions methods
  async getAiSuggestion(id: number): Promise<AiSuggestion | undefined> {
    return this.aiSuggestionsMap.get(id);
  }

  async getPatientAiSuggestions(patientId: number): Promise<AiSuggestion[]> {
    return Array.from(this.aiSuggestionsMap.values())
      .filter((suggestion) => suggestion.patientId === patientId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createAiSuggestion(suggestionData: InsertAiSuggestion): Promise<AiSuggestion> {
    const id = this.aiSuggestionId++;
    const now = new Date();
    
    const suggestion: AiSuggestion = {
      ...suggestionData,
      id,
      createdAt: now,
      reviewedAt: null,
      reviewedBy: null
    };
    
    this.aiSuggestionsMap.set(id, suggestion);
    return suggestion;
  }

  async updateAiSuggestion(id: number, suggestionData: Partial<AiSuggestion>): Promise<AiSuggestion> {
    const suggestion = this.aiSuggestionsMap.get(id);
    
    if (!suggestion) {
      throw new Error(`AI suggestion with ID ${id} not found`);
    }
    
    const updatedSuggestion = {
      ...suggestion,
      ...suggestionData
    };
    
    // If status changed, set reviewedAt and reviewedBy if provided
    if (suggestionData.status && suggestionData.status !== suggestion.status) {
      updatedSuggestion.reviewedAt = new Date();
      
      if (suggestionData.reviewedBy) {
        updatedSuggestion.reviewedBy = suggestionData.reviewedBy;
      }
    }
    
    this.aiSuggestionsMap.set(id, updatedSuggestion);
    return updatedSuggestion;
  }

  async getAiSuggestions(): Promise<AiSuggestion[]> {
    return Array.from(this.aiSuggestionsMap.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getPendingAiSuggestionsCount(): Promise<number> {
    return Array.from(this.aiSuggestionsMap.values()).filter(
      (suggestion) => suggestion.status === "pending"
    ).length;
  }

  async getRecentAiSuggestions(limit: number): Promise<AiSuggestion[]> {
    return Array.from(this.aiSuggestionsMap.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  // Audit Log methods
  async createAuditLog(logData: InsertAuditLog): Promise<AuditLog> {
    const id = this.auditLogId++;
    const now = new Date();
    
    const log: AuditLog = {
      ...logData,
      id,
      timestamp: now
    };
    
    this.auditLogsMap.set(id, log);
    return log;
  }

  async getAuditLogs(action?: string, resourceType?: string, dateRange?: string): Promise<AuditLog[]> {
    let logs = Array.from(this.auditLogsMap.values());
    
    // Filter by action if provided
    if (action && action !== "all") {
      logs = logs.filter((log) => log.action === action);
    }
    
    // Filter by resource type if provided
    if (resourceType && resourceType !== "all") {
      logs = logs.filter((log) => log.resourceType === resourceType);
    }
    
    // Filter by date range if provided
    if (dateRange && dateRange !== "all") {
      const now = new Date();
      let fromDate = new Date();
      
      switch (dateRange) {
        case "today":
          fromDate.setHours(0, 0, 0, 0);
          break;
        case "week":
          fromDate.setDate(now.getDate() - 7);
          break;
        case "month":
          fromDate.setMonth(now.getMonth() - 1);
          break;
      }
      
      logs = logs.filter((log) => new Date(log.timestamp) >= fromDate);
    }
    
    // Sort by timestamp (newest first)
    return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
}

export const storage = new MemStorage();
