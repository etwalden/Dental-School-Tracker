import OpenAI from "openai";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

// Initialize OpenAI client
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "dummy-api-key-for-development"
});

/**
 * Generate treatment suggestions based on dental chart data
 * @param patientId Patient ID to generate suggestions for
 * @param chartData Optional dental chart data (if not provided, retrieves from storage)
 * @returns Generated treatment suggestions
 */
export async function generateTreatmentSuggestions(patientId: number, chartData?: any): Promise<{ content: string }> {
  try {
    // Get patient data
    const patient = await storage.getPatient(patientId);
    
    if (!patient) {
      throw new Error(`Patient with ID ${patientId} not found`);
    }
    
    // Get dental chart if not provided
    let dentalChartData = chartData;
    if (!dentalChartData) {
      const dentalChart = await storage.getPatientDentalChart(patientId);
      dentalChartData = dentalChart?.data;
    }
    
    // If still no dental chart data, return default suggestion
    if (!dentalChartData) {
      return { 
        content: "Based on the patient's profile, recommend a comprehensive dental examination and cleaning to establish baseline oral health status." 
      };
    }
    
    // Get clinical notes for context
    const clinicalNotes = await storage.getPatientClinicalNotes(patientId);
    const notesText = clinicalNotes.map(note => note.content).join("\n\n");
    
    // Prepare the prompt
    const prompt = `
      You are a dental AI assistant helping a dentist provide treatment recommendations.
      
      Patient Information:
      - Name: ${patient.firstName} ${patient.lastName}
      - Age: ${calculateAge(new Date(patient.dateOfBirth))}
      - Medical History: ${patient.medicalHistory || "None"}
      - Allergies: ${patient.allergies || "None"}
      
      Dental Chart Data:
      ${JSON.stringify(dentalChartData, null, 2)}
      
      Clinical Notes:
      ${notesText || "No clinical notes available"}
      
      Based on the dental chart and clinical information, provide a concise, professional treatment suggestion.
      Focus on specific teeth that need attention and appropriate dental procedures.
      Your suggestion should be evidence-based and follow dental best practices.
      Keep your response under 200 words and in a single paragraph.
      
      Respond with ONLY the treatment suggestion, no introductions or explanations.
    `;
    
    // Call OpenAI API
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: "You are a dental AI assistant that provides professional treatment suggestions based on dental chart data." },
        { role: "user", content: prompt }
      ],
      max_tokens: 300,
      temperature: 0.2, // Lower temperature for more consistent, professional responses
    });
    
    // Return the content
    return { content: response.choices[0].message.content?.trim() || "No suggestion generated." };
  } catch (error) {
    console.error("Error generating treatment suggestions:", error);
    
    // Fallback response
    return { 
      content: "Based on the dental chart, consider scheduling a follow-up examination to assess the patient's oral health status in more detail." 
    };
  }
}

/**
 * Generate a clinical note based on patient data and procedure
 * @param patientId Patient ID
 * @param procedure Dental procedure performed
 * @returns Generated clinical note
 */
export async function generateClinicalNote(patientId: number, procedure: string): Promise<{ note: string }> {
  try {
    // Get patient data
    const patient = await storage.getPatient(patientId);
    
    if (!patient) {
      throw new Error(`Patient with ID ${patientId} not found`);
    }
    
    // Get dental chart data
    const dentalChart = await storage.getPatientDentalChart(patientId);
    
    // Get previous clinical notes
    const clinicalNotes = await storage.getPatientClinicalNotes(patientId);
    const previousNotes = clinicalNotes.length > 0 
      ? clinicalNotes[0].content 
      : "No previous clinical notes available.";
    
    // Prepare the prompt
    const prompt = `
      You are a dental professional writing a clinical note for a patient after a ${procedure}.
      
      Patient Information:
      - Name: ${patient.firstName} ${patient.lastName}
      - Age: ${calculateAge(new Date(patient.dateOfBirth))}
      - Medical History: ${patient.medicalHistory || "None"}
      - Allergies: ${patient.allergies || "None"}
      
      Previous Clinical Note:
      ${previousNotes}
      
      Dental Chart Information:
      ${dentalChart ? JSON.stringify(dentalChart.data, null, 2) : "No dental chart available"}
      
      Write a comprehensive clinical note for this ${procedure} appointment.
      Include relevant observations, procedures performed, patient response, and follow-up recommendations.
      Use proper dental terminology and maintain a professional tone.
      The note should be structured with clear sections and approximately 200-300 words.
      
      Respond with ONLY the clinical note in paragraph form, no introductions or explanations.
    `;
    
    // Call OpenAI API
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: "You are a dental professional writing clinical notes with accurate terminology and professional structure." },
        { role: "user", content: prompt }
      ],
      max_tokens: 800,
      temperature: 0.3,
    });
    
    // Return the generated note
    return { note: response.choices[0].message.content?.trim() || "No clinical note generated." };
  } catch (error) {
    console.error("Error generating clinical note:", error);
    
    // Fallback response
    return { 
      note: `Patient presented for ${procedure}. Examination performed. No complications noted. Follow-up recommended in 6 months.` 
    };
  }
}

/**
 * Chat with AI assistant for dental questions
 * @param message User message
 * @param userId User ID
 * @returns AI response
 */
export async function chatWithAI(message: string, userId: number): Promise<{ reply: string }> {
  try {
    // Get user data for context
    const user = await storage.getUser(userId);
    const userRole = user?.role || "dentist";
    
    // Prepare the prompt with system instructions tailored to dental context
    const systemPrompt = `
      You are a helpful dental assistant AI for a dental student management system.
      You can answer questions about:
      - Dental procedures and techniques
      - Patient care best practices
      - Dental materials and instruments
      - Oral health education
      - Basic dental school curriculum topics
      
      Do NOT:
      - Provide specific patient diagnoses or treatment plans (as this would require examination)
      - Claim to replace professional dental judgment
      - Discuss non-dental medical topics in detail
      - Share information about specific patients
      
      Always clarify that your information is for educational purposes only.
      Be concise, accurate, and helpful, using proper dental terminology.
      
      The user is a ${userRole} using a dental practice management system.
    `;
    
    // Call OpenAI API
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });
    
    // Return the response
    return { reply: response.choices[0].message.content?.trim() || "I'm sorry, I couldn't process that request." };
  } catch (error) {
    console.error("Error chatting with AI:", error);
    
    // Fallback response
    return { 
      reply: "I apologize, but I'm having trouble processing your request at the moment. Please try again later or contact technical support if the issue persists." 
    };
  }
}

/**
 * Calculate age from date of birth
 * @param dateOfBirth Date of birth
 * @returns Age in years
 */
function calculateAge(dateOfBirth: Date): number {
  const today = new Date();
  let age = today.getFullYear() - dateOfBirth.getFullYear();
  const monthDifference = today.getMonth() - dateOfBirth.getMonth();
  
  if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < dateOfBirth.getDate())) {
    age--;
  }
  
  return age;
}

// Functions are already exported individually
