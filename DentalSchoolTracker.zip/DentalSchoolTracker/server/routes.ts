import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { authenticate, requireAuth, requireAdmin } from "./auth";
import { z } from "zod";
import * as schema from "../shared/schema";
import { generateTreatmentSuggestions, generateClinicalNote, chatWithAI } from "./openai";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

// Utility function to handle async routes
const asyncHandler = (fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) => 
  (req: Request, res: Response, next: NextFunction) => 
    Promise.resolve(fn(req, res, next)).catch(next);

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post('/api/auth/login', asyncHandler(async (req: Request, res: Response) => {
    const loginData = schema.loginSchema.parse(req.body);
    const user = await storage.getUserByUsername(loginData.username);
    
    if (!user) {
      return res.status(401).json({ message: "Invalid username or password" });
    }
    
    const passwordMatch = await bcrypt.compare(loginData.password, user.password);
    
    if (!passwordMatch) {
      // Log failed login attempt
      await storage.createAuditLog({
        userId: user.id,
        action: "login",
        resourceType: "session",
        resourceId: "failed", 
        details: "Failed login attempt",
        ipAddress: req.ip,
        userAgent: req.headers["user-agent"] || ""
      });
      
      return res.status(401).json({ message: "Invalid username or password" });
    }
    
    // Create session
    req.session.userId = user.id;
    
    // Log successful login
    await storage.createAuditLog({
      userId: user.id,
      action: "login",
      resourceType: "session",
      resourceId: "success",
      details: "User logged in successfully",
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    // Update last login timestamp
    await storage.updateUserLastLogin(user.id);
    
    // Return user data (without password)
    const { password, ...userWithoutPassword } = user;
    return res.status(200).json(userWithoutPassword);
  }));
  
  app.post('/api/auth/logout', asyncHandler(async (req: Request, res: Response) => {
    const userId = req.session.userId;
    
    if (userId) {
      // Log logout
      await storage.createAuditLog({
        userId,
        action: "logout",
        resourceType: "session",
        resourceId: "self",
        details: "User logged out",
        ipAddress: req.ip,
        userAgent: req.headers["user-agent"] || ""
      });
    }
    
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  }));

  app.get('/api/auth/status', asyncHandler(async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(req.session.userId);
    
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    
    // Return user data (without password)
    const { password, ...userWithoutPassword } = user;
    return res.status(200).json(userWithoutPassword);
  }));

  // User routes
  app.get('/api/users', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const users = await storage.getAllUsers();
    
    // Remove passwords from response
    const usersWithoutPasswords = users.map(user => {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    });
    
    return res.status(200).json(usersWithoutPasswords);
  }));

  app.get('/api/users/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "view",
      resourceType: "user",
      resourceId: userId.toString(),
      details: `Viewed user profile for user ID: ${userId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    // Return user data (without password)
    const { password, ...userWithoutPassword } = user;
    return res.status(200).json(userWithoutPassword);
  }));

  app.patch('/api/users/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    
    // Users can only update their own profile unless they're an admin
    if (req.session.userId !== userId) {
      const currentUser = await storage.getUser(req.session.userId!);
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Unauthorized to update this user" });
      }
    }
    
    // If password is being updated, hash it
    if (req.body.password) {
      const salt = await bcrypt.genSalt(10);
      req.body.password = await bcrypt.hash(req.body.password, salt);
    }
    
    const updatedUser = await storage.updateUser(userId, req.body);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "update",
      resourceType: "user",
      resourceId: userId.toString(),
      details: `Updated user profile for user ID: ${userId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    // Return updated user (without password)
    const { password, ...userWithoutPassword } = updatedUser;
    return res.status(200).json(userWithoutPassword);
  }));

  // Patient routes
  app.get('/api/patients', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patients = await storage.getAllPatients();
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "view",
      resourceType: "patient",
      resourceId: "all",
      details: "Viewed list of all patients",
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(200).json(patients);
  }));

  app.get('/api/patients/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patientId = parseInt(req.params.id);
    const patient = await storage.getPatient(patientId);
    
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" });
    }
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "view",
      resourceType: "patient",
      resourceId: patientId.toString(),
      details: `Viewed patient record for patient ID: ${patientId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(200).json(patient);
  }));

  app.post('/api/patients', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patientData = schema.insertPatientSchema.parse(req.body);
    const newPatient = await storage.createPatient(patientData);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "create",
      resourceType: "patient",
      resourceId: newPatient.id.toString(),
      details: `Created new patient record: ${newPatient.firstName} ${newPatient.lastName}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(201).json(newPatient);
  }));

  app.patch('/api/patients/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patientId = parseInt(req.params.id);
    const updatedPatient = await storage.updatePatient(patientId, req.body);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "update",
      resourceType: "patient",
      resourceId: patientId.toString(),
      details: `Updated patient record for patient ID: ${patientId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(200).json(updatedPatient);
  }));

  // Appointment routes
  app.get('/api/appointments', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    // Support filtering by date
    const from = req.query.from ? new Date(req.query.from as string) : undefined;
    const to = req.query.to ? new Date(req.query.to as string) : undefined;
    
    const appointments = await storage.getAppointments(from, to);
    return res.status(200).json(appointments);
  }));

  app.get('/api/appointments/patient/:patientId', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patientId = parseInt(req.params.patientId);
    const appointments = await storage.getPatientAppointments(patientId);
    return res.status(200).json(appointments);
  }));

  app.post('/api/appointments', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const appointmentData = schema.insertAppointmentSchema.parse(req.body);
    const newAppointment = await storage.createAppointment(appointmentData);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "create",
      resourceType: "appointment",
      resourceId: newAppointment.id.toString(),
      details: `Created new appointment for patient ID: ${newAppointment.patientId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(201).json(newAppointment);
  }));

  app.patch('/api/appointments/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const appointmentId = parseInt(req.params.id);
    const updatedAppointment = await storage.updateAppointment(appointmentId, req.body);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "update",
      resourceType: "appointment",
      resourceId: appointmentId.toString(),
      details: `Updated appointment: ${appointmentId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(200).json(updatedAppointment);
  }));

  // Dental Chart routes
  app.get('/api/dental-charts/patient/:patientId', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patientId = parseInt(req.params.patientId);
    const dentalChart = await storage.getPatientDentalChart(patientId);
    
    if (!dentalChart) {
      return res.status(404).json({ message: "Dental chart not found" });
    }
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "view",
      resourceType: "dental-chart",
      resourceId: dentalChart.id.toString(),
      details: `Viewed dental chart for patient ID: ${patientId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(200).json(dentalChart);
  }));

  app.get('/api/dental-charts/recent', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const recentCharts = await storage.getRecentDentalCharts(3);
    return res.status(200).json(recentCharts);
  }));

  app.post('/api/dental-charts', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const chartData = schema.insertDentalChartSchema.parse(req.body);
    const newChart = await storage.createDentalChart(chartData);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "create",
      resourceType: "dental-chart",
      resourceId: newChart.id.toString(),
      details: `Created dental chart for patient ID: ${newChart.patientId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(201).json(newChart);
  }));

  app.patch('/api/dental-charts/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const chartId = parseInt(req.params.id);
    const updatedChart = await storage.updateDentalChart(chartId, req.body);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "update",
      resourceType: "dental-chart",
      resourceId: chartId.toString(),
      details: `Updated dental chart for patient ID: ${updatedChart.patientId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(200).json(updatedChart);
  }));

  // Clinical Notes routes
  app.get('/api/clinical-notes', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const clinicalNotes = await storage.getAllClinicalNotes();
    return res.status(200).json(clinicalNotes);
  }));

  app.get('/api/clinical-notes/patient/:patientId', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patientId = parseInt(req.params.patientId);
    const clinicalNotes = await storage.getPatientClinicalNotes(patientId);
    return res.status(200).json(clinicalNotes);
  }));

  app.post('/api/clinical-notes', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const noteData = schema.insertClinicalNoteSchema.parse(req.body);
    const newNote = await storage.createClinicalNote(noteData);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "create",
      resourceType: "clinical-note",
      resourceId: newNote.id.toString(),
      details: `Created clinical note for patient ID: ${newNote.patientId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(201).json(newNote);
  }));

  // Treatments routes
  app.get('/api/treatments/patient/:patientId', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patientId = parseInt(req.params.patientId);
    const treatments = await storage.getPatientTreatments(patientId);
    return res.status(200).json(treatments);
  }));

  app.post('/api/treatments', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const treatmentData = schema.insertTreatmentSchema.parse(req.body);
    const newTreatment = await storage.createTreatment(treatmentData);
    
    // Log audit
    await storage.createAuditLog({
      userId: req.session.userId!,
      action: "create",
      resourceType: "treatment",
      resourceId: newTreatment.id.toString(),
      details: `Created treatment record for patient ID: ${newTreatment.patientId}`,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"] || ""
    });
    
    return res.status(201).json(newTreatment);
  }));

  // AI Suggestions routes
  app.get('/api/ai-suggestions', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const suggestions = await storage.getAiSuggestions();
    return res.status(200).json(suggestions);
  }));

  app.get('/api/ai-suggestions/patient/:patientId', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const patientId = parseInt(req.params.patientId);
    const suggestions = await storage.getPatientAiSuggestions(patientId);
    return res.status(200).json(suggestions);
  }));

  app.post('/api/ai-suggestions', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const suggestionData = schema.insertAiSuggestionSchema.parse(req.body);
    const newSuggestion = await storage.createAiSuggestion(suggestionData);
    return res.status(201).json(newSuggestion);
  }));

  app.patch('/api/ai-suggestions/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const suggestionId = parseInt(req.params.id);
    const updatedSuggestion = await storage.updateAiSuggestion(suggestionId, req.body);
    return res.status(200).json(updatedSuggestion);
  }));

  app.post('/api/ai-suggestions/generate', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    // Generate suggestions using OpenAI
    const suggestions = await storage.getRecentAiSuggestions(5);
    
    // Generate new AI suggestions for various patients
    const patients = await storage.getAllPatients();
    
    if (patients.length > 0) {
      // Generate 3 random suggestions for demonstration
      for (let i = 0; i < Math.min(3, patients.length); i++) {
        const randIndex = Math.floor(Math.random() * patients.length);
        const patient = patients[randIndex];
        
        // Generate suggestion
        const basedOnOptions = ["dental chart", "clinical history", "x-ray analysis"];
        const basedOn = basedOnOptions[Math.floor(Math.random() * basedOnOptions.length)];
        
        // Generate content based on the type
        const suggestion = await generateTreatmentSuggestions(patient.id);
        
        // Save the suggestion
        await storage.createAiSuggestion({
          patientId: patient.id,
          suggestedBy: "gpt-4o",
          content: suggestion.content,
          basedOn,
          status: "pending"
        });
      }
    }
    
    // Return all suggestions
    const allSuggestions = await storage.getAiSuggestions();
    return res.status(200).json(allSuggestions);
  }));

  app.post('/api/ai-suggestions/generate-from-chart', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const { patientId, chartData } = req.body;
    
    // Generate treatment suggestions based on dental chart
    const suggestion = await generateTreatmentSuggestions(patientId, chartData);
    
    // Save the suggestion
    const newSuggestion = await storage.createAiSuggestion({
      patientId,
      suggestedBy: "gpt-4o",
      content: suggestion.content,
      basedOn: "dental chart",
      status: "pending"
    });
    
    return res.status(201).json(newSuggestion);
  }));

  // Audit Logs routes
  app.get('/api/audit-logs', requireAuth, requireAdmin, asyncHandler(async (req: Request, res: Response) => {
    // Support filtering
    const action = req.query.action as string;
    const resource = req.query.resource as string;
    const dateRange = req.query.dateRange as string;
    
    const auditLogs = await storage.getAuditLogs(action, resource, dateRange);
    return res.status(200).json(auditLogs);
  }));

  app.post('/api/audit-logs', asyncHandler(async (req: Request, res: Response) => {
    const logData = schema.insertAuditLogSchema.parse(req.body);
    
    // Capture IP address if not provided
    if (!logData.ipAddress) {
      logData.ipAddress = req.ip;
    }
    
    // Capture user agent if not provided
    if (!logData.userAgent) {
      logData.userAgent = req.headers["user-agent"] || "";
    }
    
    const newLog = await storage.createAuditLog(logData);
    return res.status(201).json(newLog);
  }));

  // Dashboard stats route
  app.get('/api/dashboard/stats', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const range = req.query.range as string || "week";
    
    // Get today's date
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Calculate date range based on specified range
    let fromDate = new Date(today);
    
    switch (range) {
      case "month":
        fromDate.setMonth(today.getMonth() - 1);
        break;
      case "quarter":
        fromDate.setMonth(today.getMonth() - 3);
        break;
      case "custom":
        // Custom would be handled with specific from/to params
        break;
      case "week":
      default:
        fromDate.setDate(today.getDate() - 7);
        break;
    }
    
    // Get stats for dashboard
    const todayAppointments = await storage.getAppointments(today);
    const pendingRecords = await storage.getPendingRecordsCount();
    const newPatients = await storage.getNewPatientsCount(fromDate);
    const aiSuggestionsCount = await storage.getPendingAiSuggestionsCount();
    
    return res.status(200).json({
      appointments: todayAppointments.length,
      pendingRecords,
      newPatients,
      aiSuggestions: aiSuggestionsCount
    });
  }));

  // AI API routes
  app.post('/api/ai/generate-clinical-note', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const { patientId, procedure } = req.body;
    
    if (!patientId || !procedure) {
      return res.status(400).json({ message: "Patient ID and procedure are required" });
    }
    
    // Get patient data
    const patient = await storage.getPatient(patientId);
    
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" });
    }
    
    // Generate clinical note
    const result = await generateClinicalNote(patientId, procedure);
    
    return res.status(200).json(result);
  }));

  app.post('/api/ai/chat', requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const { message, userId } = req.body;
    
    if (!message) {
      return res.status(400).json({ message: "Message is required" });
    }
    
    // Get response from AI chatbot
    const result = await chatWithAI(message, userId);
    
    return res.status(200).json(result);
  }));

  // Health check route
  app.get('/api/health', (req: Request, res: Response) => {
    return res.status(200).json({ status: "healthy" });
  });

  const httpServer = createServer(app);
  return httpServer;
}
