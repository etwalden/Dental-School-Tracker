import { Request, Response, NextFunction } from "express";
import { storage } from "./storage";

// Middleware to authenticate requests
export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  // Check if user is authenticated via session
  if (req.session.userId) {
    try {
      const user = await storage.getUser(req.session.userId);
      
      if (user) {
        // Attach user to request for use in downstream middleware
        req.user = user;
        return next();
      }
    } catch (error) {
      console.error("Authentication error:", error);
    }
  }
  
  // If no valid session or user not found, return unauthorized
  return res.status(401).json({ message: "Unauthorized" });
};

// Middleware to require authentication
export const requireAuth = async (req: Request, res: Response, next: NextFunction) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  try {
    const user = await storage.getUser(req.session.userId);
    
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    
    // Attach user to request for use in downstream middleware
    req.user = user;
    next();
  } catch (error) {
    console.error("Authentication error:", error);
    return res.status(500).json({ message: "Authentication error" });
  }
};

// Middleware to require admin role
export const requireAdmin = async (req: Request, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  if (req.user.role !== "admin") {
    return res.status(403).json({ message: "Admin access required" });
  }
  
  next();
};

// Middleware to validate HIPAA compliance
export const requireHipaaCompliance = async (req: Request, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  // Check if request should be logged for HIPAA compliance
  const shouldLog = [
    "/api/patients",
    "/api/appointments",
    "/api/dental-charts",
    "/api/clinical-notes",
    "/api/treatments"
  ].some(path => req.path.startsWith(path));
  
  if (shouldLog) {
    try {
      // Log access to PHI for HIPAA compliance
      await storage.createAuditLog({
        userId: req.user.id,
        action: req.method === "GET" ? "view" : 
                req.method === "POST" ? "create" : 
                req.method === "PATCH" || req.method === "PUT" ? "update" : 
                req.method === "DELETE" ? "delete" : "access",
        resourceType: req.path.split("/")[2] || "unknown",
        resourceId: req.params.id || "multiple",
        details: `${req.method} ${req.path}`,
        ipAddress: req.ip,
        userAgent: req.headers["user-agent"] || ""
      });
    } catch (error) {
      console.error("HIPAA audit logging error:", error);
      // Continue processing even if audit logging fails
    }
  }
  
  next();
};

// Add type definition for user in session
declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

// Add type definition for user in request
declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}
